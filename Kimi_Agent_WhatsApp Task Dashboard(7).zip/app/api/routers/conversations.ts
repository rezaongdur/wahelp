import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { conversations, contacts, messages } from "../../db/schema";
import { eq, desc, asc } from "drizzle-orm";

export const conversationsRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({ conv: conversations, contact: contacts })
      .from(conversations)
      .innerJoin(contacts, eq(conversations.contactId, contacts.id))
      .orderBy(desc(conversations.lastMessageAt));
    return rows.map((r) => ({
      id: r.conv.id,
      contactId: r.contact.id,
      contactName: r.contact.name,
      waNumber: r.contact.waNumber,
      lastMessageAt: r.conv.lastMessageAt,
      lastMessagePreview: r.conv.lastMessagePreview,
      unreadCount: r.conv.unreadCount,
      botState: r.conv.botState,
      status: r.conv.status,
    }));
  }),

  detail: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const conv = (await db.select().from(conversations).where(eq(conversations.id, input.id)).limit(1))[0];
      if (!conv) throw new Error("Percakapan tidak ditemukan");
      const contact = (await db.select().from(contacts).where(eq(contacts.id, conv.contactId)).limit(1))[0];
      const msgs = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.id))
        .orderBy(asc(messages.createdAt));
      return { conversation: conv, contact, messages: msgs };
    }),

  sendMessage: publicQuery
    .input(z.object({ conversationId: z.number(), body: z.string().min(1) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const now = new Date();
      const res = await db.insert(messages).values({
        conversationId: input.conversationId,
        direction: "out",
        senderType: "admin",
        body: input.body,
        createdAt: now,
      });
      // Admin membalas manual → bot otomatis diam (handoff), sesuai aturan.
      await db
        .update(conversations)
        .set({
          lastMessageAt: now,
          lastMessagePreview: input.body.slice(0, 200),
          unreadCount: 0,
          botState: "handoff",
        })
        .where(eq(conversations.id, input.conversationId));
      return { id: Number(res[0].insertId) };
    }),

  setBotState: publicQuery
    .input(z.object({ conversationId: z.number(), state: z.enum(["active", "handoff"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(conversations)
        .set({ botState: input.state })
        .where(eq(conversations.id, input.conversationId));
      return { ok: true };
    }),

  markRead: publicQuery
    .input(z.object({ conversationId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(conversations)
        .set({ unreadCount: 0 })
        .where(eq(conversations.id, input.conversationId));
      return { ok: true };
    }),

  resolve: publicQuery
    .input(z.object({ conversationId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(conversations)
        .set({ status: "resolved" })
        .where(eq(conversations.id, input.conversationId));
      return { ok: true };
    }),
});
