import { z } from "zod";
import QRCode from "qrcode";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { waSessions } from "../../db/schema";
import { eq } from "drizzle-orm";
import { processInbound } from "../services/inbound";
import crypto from "node:crypto";

async function getSession() {
  const db = getDb();
  const rows = await db.select().from(waSessions).limit(1);
  return rows[0] ?? null;
}

export const whatsappRouter = createRouter({
  status: publicQuery.query(async () => {
    const s = await getSession();
    if (!s) return { status: "disconnected" as const, phoneNumber: null, pushName: null, connectedAt: null, qrToken: null, qrDataUrl: null };
    let qrDataUrl: string | null = null;
    if (s.status === "waiting_scan" && s.qrToken) {
      const payload = `wahelpdesk://pair?token=${s.qrToken}&v=1`;
      qrDataUrl = await QRCode.toDataURL(payload, { width: 320, margin: 1 });
    }
    return {
      status: s.status,
      phoneNumber: s.phoneNumber,
      pushName: s.pushName,
      connectedAt: s.connectedAt,
      qrToken: s.qrToken,
      qrDataUrl,
    };
  }),

  connect: publicQuery.mutation(async () => {
    const db = getDb();
    const token = crypto.randomBytes(24).toString("hex");
    const now = new Date();
    const existing = await getSession();
    if (existing) {
      await db
        .update(waSessions)
        .set({ status: "waiting_scan", qrToken: token, qrCreatedAt: now, updatedAt: now })
        .where(eq(waSessions.id, existing.id));
    } else {
      await db.insert(waSessions).values({
        status: "waiting_scan",
        qrToken: token,
        qrCreatedAt: now,
        updatedAt: now,
      });
    }
    const payload = `wahelpdesk://pair?token=${token}&v=1`;
    const qrDataUrl = await QRCode.toDataURL(payload, { width: 320, margin: 1 });
    return { qrToken: token, qrDataUrl };
  }),

  // Mode demo: mensimulasikan pemindaian QR oleh ponsel.
  // Di produksi, langkah ini dilakukan gateway WhatsApp (Baileys/Meta) secara nyata.
  simulateScan: publicQuery.mutation(async () => {
    const db = getDb();
    const s = await getSession();
    if (!s || s.status !== "waiting_scan") throw new Error("Tidak ada sesi QR yang menunggu pindaian.");
    const now = new Date();
    await db
      .update(waSessions)
      .set({
        status: "connected",
        phoneNumber: "6281234567890",
        pushName: "Helpdesk Bapenda (Demo)",
        connectedAt: now,
        qrToken: null,
        updatedAt: now,
      })
      .where(eq(waSessions.id, s.id));
    return { ok: true };
  }),

  disconnect: publicQuery.mutation(async () => {
    const db = getDb();
    const s = await getSession();
    if (s) {
      await db
        .update(waSessions)
        .set({ status: "disconnected", qrToken: null, updatedAt: new Date() })
        .where(eq(waSessions.id, s.id));
    }
    return { ok: true };
  }),

  // Simulator pesan masuk (demo) — di produksi pesan masuk lewat webhook Meta.
  simulateInbound: publicQuery
    .input(z.object({ waNumber: z.string().min(5), contactName: z.string().optional(), body: z.string().min(1) }))
    .mutation(async ({ input }) => {
      return processInbound({ waNumber: input.waNumber, contactName: input.contactName, body: input.body });
    }),
});
