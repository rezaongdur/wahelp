import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { tasks, conversations, contacts, messages } from "../../db/schema";
import { eq, desc, asc, and, sql } from "drizzle-orm";
import { extractTaskDraft } from "../services/botEngine";
import { TASK_STATUSES, BEBAN_OPTIONS, SUMBER_OPTIONS } from "@contracts/constants";

const taskInput = z.object({
  pemohon: z.string().min(1),
  waNumber: z.string().optional().nullable(),
  tanggalPemohon: z.string().min(8),
  tanggalHarusSelesai: z.string().optional().nullable(),
  tugas: z.string().min(1),
  keterangan: z.string().optional().nullable(),
  status: z.enum(TASK_STATUSES).optional(),
  sumber: z.enum(SUMBER_OPTIONS).optional(),
  conversationId: z.number().optional().nullable(),
  masalah: z.string().optional().nullable(),
  caraPenyelesaian: z.string().optional().nullable(),
  tanggalJatuhTempo: z.string().optional().nullable(),
  tujuanTugas: z.string().optional().nullable(),
  beban: z.enum(BEBAN_OPTIONS).optional().nullable(),
  waktuPenyelesaian: z.string().optional().nullable(),
  dasarAnalisis: z.string().optional().nullable(),
});

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export const tasksRouter = createRouter({
  summary: publicQuery.query(async () => {
    const db = getDb();
    const rows = await db.select().from(tasks);
    const today = todayStr();
    const s = { baru: 0, diproses: 0, selesai: 0, terlambat: 0, aktif: 0 };
    for (const t of rows) {
      s[t.status]++;
      if (t.status !== "selesai") {
        s.aktif++;
        if (t.tanggalHarusSelesai && t.tanggalHarusSelesai < today) s.terlambat++;
      }
    }
    return s;
  }),

  list: publicQuery
    .input(
      z.object({
        q: z.string().optional(),
        status: z.enum(TASK_STATUSES).optional(),
        beban: z.enum(BEBAN_OPTIONS).optional(),
        sumber: z.enum(SUMBER_OPTIONS).optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conds = [];
      if (input.status) conds.push(eq(tasks.status, input.status));
      if (input.beban) conds.push(eq(tasks.beban, input.beban));
      if (input.sumber) conds.push(eq(tasks.sumber, input.sumber));
      if (input.q) {
        const q = `%${input.q}%`;
        conds.push(
          sql`(${tasks.pemohon} LIKE ${q} OR ${tasks.tugas} LIKE ${q} OR ${tasks.masalah} LIKE ${q} OR ${tasks.waNumber} LIKE ${q})`
        );
      }
      const rows = await db
        .select()
        .from(tasks)
        .where(conds.length ? and(...conds) : undefined)
        .orderBy(desc(tasks.createdAt));
      return rows.map((t) => ({ ...t, today: todayStr() }));
    }),

  get: publicQuery.input(z.object({ id: z.number() })).query(async ({ input }) => {
    const db = getDb();
    const t = (await db.select().from(tasks).where(eq(tasks.id, input.id)).limit(1))[0];
    if (!t) throw new Error("Tugas tidak ditemukan");
    let convInfo: { id: number; contactName: string; waNumber: string } | null = null;
    if (t.conversationId) {
      const conv = (
        await db.select().from(conversations).where(eq(conversations.id, t.conversationId)).limit(1)
      )[0];
      if (conv) {
        const c = (await db.select().from(contacts).where(eq(contacts.id, conv.contactId)).limit(1))[0];
        if (c) convInfo = { id: conv.id, contactName: c.name, waNumber: c.waNumber };
      }
    }
    return { ...t, today: todayStr(), conversationInfo: convInfo };
  }),

  create: publicQuery.input(taskInput).mutation(async ({ input }) => {
    const db = getDb();
    const res = await db.insert(tasks).values({
      ...input,
      waNumber: input.waNumber ?? null,
      tanggalHarusSelesai: input.tanggalHarusSelesai || null,
      keterangan: input.keterangan ?? null,
      status: input.status ?? "baru",
      sumber: input.sumber ?? "manual",
      conversationId: input.conversationId ?? null,
      masalah: input.masalah ?? null,
      caraPenyelesaian: input.caraPenyelesaian ?? null,
      tanggalJatuhTempo: input.tanggalJatuhTempo || null,
      tujuanTugas: input.tujuanTugas ?? null,
      beban: input.beban ?? null,
      waktuPenyelesaian: input.waktuPenyelesaian ?? null,
      dasarAnalisis: input.dasarAnalisis ?? null,
      completedAt: input.status === "selesai" ? new Date() : null,
    });
    return { id: Number(res[0].insertId) };
  }),

  update: publicQuery
    .input(taskInput.extend({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...rest } = input;
      const existing = (await db.select().from(tasks).where(eq(tasks.id, id)).limit(1))[0];
      if (!existing) throw new Error("Tugas tidak ditemukan");
      await db
        .update(tasks)
        .set({
          ...rest,
          waNumber: rest.waNumber ?? null,
          tanggalHarusSelesai: rest.tanggalHarusSelesai || null,
          keterangan: rest.keterangan ?? null,
          conversationId: rest.conversationId ?? existing.conversationId,
          masalah: rest.masalah ?? null,
          caraPenyelesaian: rest.caraPenyelesaian ?? null,
          tanggalJatuhTempo: rest.tanggalJatuhTempo || null,
          tujuanTugas: rest.tujuanTugas ?? null,
          beban: rest.beban ?? null,
          waktuPenyelesaian: rest.waktuPenyelesaian ?? null,
          dasarAnalisis: rest.dasarAnalisis ?? existing.dasarAnalisis,
          completedAt:
            rest.status === "selesai" && existing.status !== "selesai"
              ? new Date()
              : rest.status !== "selesai"
                ? null
                : existing.completedAt,
          updatedAt: new Date(),
        })
        .where(eq(tasks.id, id));
      return { ok: true };
    }),

  remove: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(tasks).where(eq(tasks.id, input.id));
    return { ok: true };
  }),

  // Rekam tugas dari percakapan: ekstraksi otomatis + dasar analisis.
  draftFromConversation: publicQuery
    .input(z.object({ conversationId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const conv = (
        await db.select().from(conversations).where(eq(conversations.id, input.conversationId)).limit(1)
      )[0];
      if (!conv) throw new Error("Percakapan tidak ditemukan");
      const contact = (await db.select().from(contacts).where(eq(contacts.id, conv.contactId)).limit(1))[0];
      const msgs = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.conversationId))
        .orderBy(asc(messages.createdAt));
      const draft = extractTaskDraft({
        contactName: contact?.name ?? "Tanpa nama",
        waNumber: contact?.waNumber ?? "",
        messages: msgs,
        now: new Date(),
      });
      return draft;
    }),
});
