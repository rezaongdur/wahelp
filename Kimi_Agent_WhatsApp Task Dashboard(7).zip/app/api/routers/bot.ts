import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { botSettings, kbEntries, botLogs, conversations, contacts } from "../../db/schema";
import { eq, desc } from "drizzle-orm";
import { getBotSettings, getKbEntries, DEFAULT_SETTINGS } from "../services/inbound";
import { decideBot } from "../services/botEngine";

export const botRouter = createRouter({
  getSettings: publicQuery.query(async () => {
    return getBotSettings();
  }),

  updateSettings: publicQuery
    .input(
      z.object({
        enabled: z.boolean().optional(),
        greetingMessage: z.string().optional(),
        fallbackMessage: z.string().optional(),
        handoffKeywords: z.array(z.string()).optional(),
        hoursStart: z.string().regex(/^\d{2}:\d{2}$/).optional(),
        hoursEnd: z.string().regex(/^\d{2}:\d{2}$/).optional(),
        workDays: z.array(z.number().min(1).max(7)).optional(),
        antiSpamSeconds: z.number().min(0).max(3600).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = (await db.select().from(botSettings).limit(1))[0];
      const values: Record<string, unknown> = { updatedAt: new Date() };
      if (input.enabled !== undefined) values.enabled = input.enabled;
      if (input.greetingMessage !== undefined) values.greetingMessage = input.greetingMessage;
      if (input.fallbackMessage !== undefined) values.fallbackMessage = input.fallbackMessage;
      if (input.handoffKeywords !== undefined) values.handoffKeywords = input.handoffKeywords.join("\n");
      if (input.hoursStart !== undefined) values.hoursStart = input.hoursStart;
      if (input.hoursEnd !== undefined) values.hoursEnd = input.hoursEnd;
      if (input.workDays !== undefined) values.workDays = JSON.stringify(input.workDays);
      if (input.antiSpamSeconds !== undefined) values.antiSpamSeconds = input.antiSpamSeconds;
      if (existing) {
        await db.update(botSettings).set(values).where(eq(botSettings.id, existing.id));
      } else {
        await db.insert(botSettings).values({
          enabled: input.enabled ?? false,
          greetingMessage: input.greetingMessage ?? DEFAULT_SETTINGS.greetingMessage,
          fallbackMessage: input.fallbackMessage ?? DEFAULT_SETTINGS.fallbackMessage,
          handoffKeywords: (input.handoffKeywords ?? DEFAULT_SETTINGS.handoffKeywords).join("\n"),
          hoursStart: input.hoursStart ?? "08:00",
          hoursEnd: input.hoursEnd ?? "16:00",
          workDays: JSON.stringify(input.workDays ?? DEFAULT_SETTINGS.workDays),
          antiSpamSeconds: input.antiSpamSeconds ?? 20,
        });
      }
      return getBotSettings();
    }),

  kbList: publicQuery.query(async () => {
    return getKbEntries(false);
  }),

  kbCreate: publicQuery
    .input(
      z.object({
        title: z.string().min(1),
        keywords: z.array(z.string().min(1)).min(1),
        answer: z.string().min(1),
        enabled: z.boolean().optional(),
        sortOrder: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const res = await db.insert(kbEntries).values({
        title: input.title,
        keywords: JSON.stringify(input.keywords),
        answer: input.answer,
        enabled: input.enabled ?? true,
        sortOrder: input.sortOrder ?? 0,
      });
      return { id: Number(res[0].insertId) };
    }),

  kbUpdate: publicQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        keywords: z.array(z.string().min(1)).min(1).optional(),
        answer: z.string().min(1).optional(),
        enabled: z.boolean().optional(),
        sortOrder: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...rest } = input;
      const values: Record<string, unknown> = {};
      if (rest.title !== undefined) values.title = rest.title;
      if (rest.keywords !== undefined) values.keywords = JSON.stringify(rest.keywords);
      if (rest.answer !== undefined) values.answer = rest.answer;
      if (rest.enabled !== undefined) values.enabled = rest.enabled;
      if (rest.sortOrder !== undefined) values.sortOrder = rest.sortOrder;
      await db.update(kbEntries).set(values).where(eq(kbEntries.id, id));
      return { ok: true };
    }),

  kbDelete: publicQuery.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
    const db = getDb();
    await db.delete(kbEntries).where(eq(kbEntries.id, input.id));
    return { ok: true };
  }),

  // Uji balasan bot tanpa mengirim apa pun.
  test: publicQuery
    .input(
      z.object({
        input: z.string().min(1),
        isNewContact: z.boolean().optional(),
      })
    )
    .query(async ({ input }) => {
      const settings = await getBotSettings();
      const entries = await getKbEntries(true);
      const verdict = decideBot({
        input: input.input,
        entries,
        settings: { ...settings, enabled: true }, // uji selalu menganggap bot aktif
        isNewContact: input.isNewContact ?? false,
        botState: "active",
        lastBotReplyAt: null,
        now: new Date(),
      });
      return verdict;
    }),

  logs: publicQuery
    .input(z.object({ limit: z.number().min(1).max(200).optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db
        .select({ log: botLogs, conv: conversations })
        .from(botLogs)
        .leftJoin(conversations, eq(botLogs.conversationId, conversations.id))
        .orderBy(desc(botLogs.createdAt))
        .limit(input.limit ?? 50);
      const out = [];
      for (const r of rows) {
        let contactName = "-";
        if (r.conv) {
          const c = (
            await db.select().from(contacts).where(eq(contacts.id, r.conv.contactId)).limit(1)
          )[0];
          if (c) contactName = c.name;
        }
        out.push({ ...r.log, contactName });
      }
      return out;
    }),
});
