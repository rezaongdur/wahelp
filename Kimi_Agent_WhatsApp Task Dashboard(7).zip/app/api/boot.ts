import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});

// Webhook WhatsApp (Meta Cloud API).
// GET = verifikasi challenge; POST = pesan masuk.
// POST membalas Meta secepatnya (~ms) — pemrosesan pesan & balasan bot
// berjalan di latar belakang agar webhook tidak pernah memblokir.
const WA_VERIFY_TOKEN = process.env.WA_VERIFY_TOKEN || "wa-helpdesk-verify";

app.get("/api/webhook/whatsapp", (c) => {
  const mode = c.req.query("hub.mode");
  const token = c.req.query("hub.verify_token");
  const challenge = c.req.query("hub.challenge");
  if (mode === "subscribe" && token === WA_VERIFY_TOKEN && challenge) {
    return c.text(challenge, 200);
  }
  return c.json({ error: "Verifikasi gagal" }, 403);
});

interface MetaWebhookPayload {
  entry?: {
    changes?: {
      value?: {
        messages?: { from: string; type?: string; text?: { body?: string } }[];
        contacts?: { profile?: { name?: string }; wa_id?: string }[];
      };
    }[];
  }[];
}

app.post("/api/webhook/whatsapp", async (c) => {
  let payload: MetaWebhookPayload | null = null;
  try {
    payload = (await c.req.json()) as MetaWebhookPayload;
  } catch {
    return c.json({ ok: true }, 200);
  }
  // Fire-and-forget: respons ke Meta tidak menunggu pemrosesan.
  void (async () => {
    try {
      const { processInbound } = await import("./services/inbound");
      const body = payload as MetaWebhookPayload | null;
      const entries = body?.entry ?? [];
      for (const entry of entries) {
        for (const change of entry.changes ?? []) {
          const value = change.value;
          if (!value?.messages) continue;
          const senderName = value.contacts?.[0]?.profile?.name;
          for (const msg of value.messages) {
            if (msg.type !== "text" || !msg.text?.body) continue;
            await processInbound({ waNumber: msg.from, contactName: senderName, body: msg.text.body });
          }
        }
      }
    } catch (err) {
      console.error("[webhook] gagal memproses pesan masuk:", err);
    }
  })();
  return c.json({ ok: true }, 200);
});

app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
