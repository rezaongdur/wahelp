// Pemrosesan pesan masuk WhatsApp: simpan pesan, jalankan keputusan bot,
// kirim balasan otomatis bila perlu, dan catat log. Dipakai oleh webhook
// Meta maupun simulator demo.
import { eq, desc } from "drizzle-orm";
import { getDb } from "../queries/connection";
import {
  botLogs,
  botSettings,
  contacts,
  conversations,
  kbEntries,
  messages,
} from "../../db/schema";
import {
  decideBot,
  type BotSettingsLite,
  type KbEntryLite,
} from "./botEngine";

export const DEFAULT_SETTINGS: BotSettingsLite = {
  enabled: false,
  greetingMessage:
    "Halo! 👋 Selamat datang di layanan Helpdesk. Saya asisten otomatis yang siap membantu. Silakan sampaikan pertanyaan Anda, atau ketik *petugas* untuk berbicara dengan petugas.",
  fallbackMessage:
    "Maaf, saya belum menemukan jawaban yang tepat untuk pertanyaan Anda. Pertanyaan Anda sudah kami catat dan akan dijawab petugas pada jam layanan. Ketik *petugas* bila ingin langsung dibantu petugas.",
  handoffKeywords: ["petugas", "admin", "manusia", "customer service", "cs"],
  hoursStart: "08:00",
  hoursEnd: "16:00",
  workDays: [1, 2, 3, 4, 5],
  antiSpamSeconds: 20,
};

function parseJsonArray<T>(raw: string | null, fallback: T[]): T[] {
  if (!raw) return fallback;
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v : fallback;
  } catch {
    return fallback;
  }
}

export async function getBotSettings(): Promise<BotSettingsLite> {
  const db = getDb();
  const rows = await db.select().from(botSettings).limit(1);
  const r = rows[0];
  if (!r) return DEFAULT_SETTINGS;
  return {
    enabled: r.enabled,
    greetingMessage: r.greetingMessage || DEFAULT_SETTINGS.greetingMessage,
    fallbackMessage: r.fallbackMessage || DEFAULT_SETTINGS.fallbackMessage,
    handoffKeywords: r.handoffKeywords
      ? r.handoffKeywords.split(/[\n,]+/).map((s) => s.trim()).filter(Boolean)
      : DEFAULT_SETTINGS.handoffKeywords,
    hoursStart: r.hoursStart || "08:00",
    hoursEnd: r.hoursEnd || "16:00",
    workDays: parseJsonArray<number>(r.workDays, DEFAULT_SETTINGS.workDays),
    antiSpamSeconds: r.antiSpamSeconds ?? 20,
  };
}

export async function getKbEntries(onlyEnabled = false): Promise<KbEntryLite[]> {
  const db = getDb();
  const rows = await db.select().from(kbEntries).orderBy(kbEntries.sortOrder);
  return rows
    .map((r) => ({
      id: r.id,
      title: r.title,
      keywords: parseJsonArray<string>(r.keywords, []),
      answer: r.answer,
      enabled: r.enabled,
    }))
    .filter((e) => !onlyEnabled || e.enabled);
}

export interface InboundResult {
  conversationId: number;
  messageId: number;
  botReplied: boolean;
  decision: string;
}

export async function processInbound(params: {
  waNumber: string;
  contactName?: string;
  body: string;
  now?: Date;
}): Promise<InboundResult> {
  const db = getDb();
  const now = params.now ?? new Date();
  const { waNumber, body } = params;

  // 1. Kontak
  let contact = (
    await db.select().from(contacts).where(eq(contacts.waNumber, waNumber)).limit(1)
  )[0];
  const isNewContact = !contact;
  if (!contact) {
    const name = params.contactName?.trim() || `WA ${waNumber}`;
    const res = await db.insert(contacts).values({ waNumber, name });
    contact = { id: Number(res[0].insertId), waNumber, name, createdAt: now };
  }

  // 2. Percakapan
  let conv = (
    await db
      .select()
      .from(conversations)
      .where(eq(conversations.contactId, contact.id))
      .orderBy(desc(conversations.lastMessageAt))
      .limit(1)
  )[0];
  if (!conv) {
    const res = await db.insert(conversations).values({
      contactId: contact.id,
      lastMessageAt: now,
    });
    conv = {
      id: Number(res[0].insertId),
      contactId: contact.id,
      lastMessageAt: now,
      lastMessagePreview: null,
      unreadCount: 0,
      botState: "active" as const,
      status: "open" as const,
      createdAt: now,
    };
  }

  // 3. Simpan pesan masuk
  const msgRes = await db.insert(messages).values({
    conversationId: conv.id,
    direction: "in",
    senderType: "contact",
    body,
    createdAt: now,
  });
  await db
    .update(conversations)
    .set({
      lastMessageAt: now,
      lastMessagePreview: body.slice(0, 200),
      unreadCount: conv.unreadCount + 1,
      status: "open",
    })
    .where(eq(conversations.id, conv.id));

  // 4. Keputusan bot
  const settings = await getBotSettings();
  const entries = await getKbEntries(true);
  const lastBotMsg = (
    await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conv.id))
      .orderBy(desc(messages.createdAt))
      .limit(50)
  ).find((m) => m.senderType === "bot");

  const verdict = decideBot({
    input: body,
    entries,
    settings,
    isNewContact,
    botState: conv.botState,
    lastBotReplyAt: lastBotMsg?.createdAt ?? null,
    now,
  });

  let botReplied = false;
  if (verdict.replyText && (verdict.decision === "auto_reply" || verdict.decision === "greeting" || verdict.decision === "fallback" || verdict.decision === "handoff")) {
    const replyAt = new Date(now.getTime() + 1000);
    await db.insert(messages).values({
      conversationId: conv.id,
      direction: "out",
      senderType: "bot",
      body: verdict.replyText,
      createdAt: replyAt,
    });
    await db
      .update(conversations)
      .set({ lastMessageAt: replyAt, lastMessagePreview: verdict.replyText.slice(0, 200) })
      .where(eq(conversations.id, conv.id));
    botReplied = true;
    if (verdict.decision === "handoff") {
      await db
        .update(conversations)
        .set({ botState: "handoff" })
        .where(eq(conversations.id, conv.id));
    }
  }

  // 5. Log keputusan
  await db.insert(botLogs).values({
    conversationId: conv.id,
    inputText: body,
    decision: verdict.decision,
    matchedKbId: verdict.matchedKbId,
    matchedTitle: verdict.matchedTitle,
    score: verdict.score,
    candidates: JSON.stringify(verdict.candidates),
    replyText: verdict.replyText,
    createdAt: now,
  });

  return { conversationId: conv.id, messageId: Number(msgRes[0].insertId), botReplied, decision: verdict.decision };
}
