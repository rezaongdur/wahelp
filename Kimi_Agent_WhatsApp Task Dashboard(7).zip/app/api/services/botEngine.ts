// Engine bot berbasis aturan/kata kunci — murni fungsi, tanpa akses DB.
// Semua keputusan bot (skor, kandidat, alasan) dikembalikan agar bisa dicatat
// ke bot_logs dan ditampilkan di tab "Uji & Log".

export interface KbEntryLite {
  id: number;
  title: string;
  keywords: string[]; // frasa kata kunci
  answer: string;
  enabled: boolean;
}

export interface BotSettingsLite {
  enabled: boolean;
  greetingMessage: string;
  fallbackMessage: string;
  handoffKeywords: string[];
  hoursStart: string; // "08:00"
  hoursEnd: string; // "16:00"
  workDays: number[]; // 1=Senin .. 7=Minggu
  antiSpamSeconds: number;
}

export type BotDecision =
  | "auto_reply"
  | "greeting"
  | "fallback"
  | "handoff"
  | "off"
  | "out_of_hours"
  | "spam_skip";

export interface BotVerdict {
  decision: BotDecision;
  replyText: string | null;
  matchedKbId: number | null;
  matchedTitle: string | null;
  score: number;
  candidates: { id: number; title: string; score: number }[];
  reason: string;
}

export function normalize(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9à-ÿ\s>/]/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function wordBoundaryIncludes(haystack: string, needle: string): boolean {
  const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|\\s)${escaped}($|\\s)`, "i").test(haystack);
}

// Skor satu entri KB terhadap teks masukan.
// Frasa multi-kata yang cocok utuh bernilai paling tinggi, lalu kata tunggal
// dengan batas kata, lalu irisan token sebagai skor kecil.
export function scoreEntry(
  normalizedInput: string,
  keywords: string[]
): number {
  let score = 0;
  const inputTokens = new Set(normalizedInput.split(" ").filter(Boolean));
  for (const kw of keywords) {
    const k = normalize(kw);
    if (!k) continue;
    if (k.includes(" ")) {
      if (normalizedInput.includes(k)) score += 6 + k.split(" ").length;
    } else if (wordBoundaryIncludes(normalizedInput, k)) {
      score += 3;
    } else if (inputTokens.has(k)) {
      score += 2;
    }
  }
  return score;
}

export function rankCandidates(
  input: string,
  entries: KbEntryLite[]
): { id: number; title: string; score: number }[] {
  const normalized = normalize(input);
  return entries
    .filter((e) => e.enabled)
    .map((e) => ({ id: e.id, title: e.title, score: scoreEntry(normalized, e.keywords) }))
    .filter((c) => c.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);
}

export const MATCH_THRESHOLD = 3;

export function decideBot(params: {
  input: string;
  entries: KbEntryLite[];
  settings: BotSettingsLite;
  isNewContact: boolean;
  botState: "active" | "handoff";
  lastBotReplyAt: Date | null;
  now: Date;
}): BotVerdict {
  const { input, entries, settings, isNewContact, botState, lastBotReplyAt, now } = params;
  const noReply = (decision: BotDecision, reason: string): BotVerdict => ({
    decision,
    replyText: null,
    matchedKbId: null,
    matchedTitle: null,
    score: 0,
    candidates: [],
    reason,
  });

  if (!settings.enabled) return noReply("off", "Bot sedang nonaktif.");
  if (botState === "handoff")
    return noReply("handoff", "Percakapan sedang ditangani admin (bot diam).");

  // Batas jam & hari layanan
  const day = now.getDay() === 0 ? 7 : now.getDay();
  if (!settings.workDays.includes(day))
    return noReply("out_of_hours", "Di luar hari layanan.");
  const [sh, sm] = settings.hoursStart.split(":").map(Number);
  const [eh, em] = settings.hoursEnd.split(":").map(Number);
  const minutes = now.getHours() * 60 + now.getMinutes();
  if (minutes < sh * 60 + sm || minutes >= eh * 60 + em)
    return noReply("out_of_hours", "Di luar jam layanan.");

  // Jeda anti-spam
  if (lastBotReplyAt) {
    const gap = (now.getTime() - lastBotReplyAt.getTime()) / 1000;
    if (gap < settings.antiSpamSeconds)
      return noReply("spam_skip", `Balasan bot terakhir ${Math.round(gap)} detik lalu (< ${settings.antiSpamSeconds} dtk).`);
  }

  // Handoff manual oleh pelanggan ("minta petugas", dsb.)
  const normalized = normalize(input);
  const handoffHit = settings.handoffKeywords.find((k) => {
    const kk = normalize(k);
    return kk && (kk.includes(" ") ? normalized.includes(kk) : wordBoundaryIncludes(normalized, kk));
  });
  if (handoffHit)
    return {
      ...noReply("handoff", `Pelanggan meminta petugas (kata kunci: "${handoffHit}").`),
      replyText:
        "Baik, saya teruskan ke petugas kami. Mohon ditunggu, petugas akan segera membalas pesan Anda. 🙏",
    };

  const candidates = rankCandidates(input, entries);
  const top = candidates[0];

  if (isNewContact) {
    return {
      decision: "greeting",
      replyText: settings.greetingMessage,
      matchedKbId: top && top.score >= MATCH_THRESHOLD ? top.id : null,
      matchedTitle: top && top.score >= MATCH_THRESHOLD ? top.title : null,
      score: top?.score ?? 0,
      candidates,
      reason: "Kontak baru — sapaan otomatis dikirim.",
    };
  }

  if (top && top.score >= MATCH_THRESHOLD) {
    const entry = entries.find((e) => e.id === top.id)!;
    return {
      decision: "auto_reply",
      replyText: entry.answer,
      matchedKbId: entry.id,
      matchedTitle: entry.title,
      score: top.score,
      candidates,
      reason: `Kecocokan "${entry.title}" (skor ${top.score} ≥ ambang ${MATCH_THRESHOLD}).`,
    };
  }

  return {
    decision: "fallback",
    replyText: settings.fallbackMessage,
    matchedKbId: null,
    matchedTitle: null,
    score: top?.score ?? 0,
    candidates,
    reason: top
      ? `Skor tertinggi ${top.score} di bawah ambang ${MATCH_THRESHOLD} — balasan cadangan.`
      : "Tidak ada kata kunci yang cocok — balasan cadangan.",
  };
}

// ---------------------------------------------------------------------------
// Parser tanggal Bahasa Indonesia
// ---------------------------------------------------------------------------

const BULAN_ID: Record<string, number> = {
  januari: 1, februari: 2, maret: 3, april: 4, mei: 5, juni: 6,
  juli: 7, agustus: 8, september: 9, oktober: 10, november: 11, desember: 12,
};

export interface ParsedDate {
  date: string; // YYYY-MM-DD
  raw: string;
  kind: "explicit" | "relative";
}

function fmt(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

function addDays(base: Date, n: number): Date {
  const d = new Date(base);
  d.setDate(d.getDate() + n);
  return d;
}

function addMonths(base: Date, n: number): Date {
  const d = new Date(base);
  d.setMonth(d.getMonth() + n);
  return d;
}

// Mengembalikan semua tanggal yang disebut dalam teks, urut kemunculan.
export function parseDates(text: string, now: Date): ParsedDate[] {
  const out: ParsedDate[] = [];
  const lower = text.toLowerCase();

  // Eksplisit: 25/09/2026, 25-9-26, 25.09.2026
  for (const m of lower.matchAll(/\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})\b/g)) {
    const dd = parseInt(m[1]);
    const mm = parseInt(m[2]);
    let yy = parseInt(m[3]);
    if (yy < 100) yy += 2000;
    if (mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31)
      out.push({ date: fmt(new Date(yy, mm - 1, dd)), raw: m[0], kind: "explicit" });
  }

  // Eksplisit: "25 september 2026" / "25 september"
  for (const m of lower.matchAll(
    /\b(\d{1,2})\s+(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember)(?:\s+(\d{4}))?\b/g
  )) {
    const dd = parseInt(m[1]);
    const mm = BULAN_ID[m[2]];
    let yy = m[3] ? parseInt(m[3]) : now.getFullYear();
    let d = new Date(yy, mm - 1, dd);
    if (!m[3] && d < addDays(now, -1)) d = new Date(yy + 1, mm - 1, dd);
    out.push({ date: fmt(d), raw: m[0], kind: "explicit" });
  }

  // Eksplisit: "tanggal 25" / "tgl 25" (bulan berjalan / depan)
  for (const m of lower.matchAll(/\b(?:tanggal|tgl)\s+(\d{1,2})\b/g)) {
    const dd = parseInt(m[1]);
    if (dd < 1 || dd > 31) continue;
    let d = new Date(now.getFullYear(), now.getMonth(), dd);
    if (d < addDays(now, -1)) d = addMonths(d, 1);
    out.push({ date: fmt(d), raw: m[0], kind: "explicit" });
  }

  // Relatif
  const rel = (re: RegExp, days: (m: RegExpMatchArray) => number, months?: (m: RegExpMatchArray) => number) => {
    for (const m of lower.matchAll(re)) {
      const d = months ? addMonths(now, months(m)) : addDays(now, days(m));
      out.push({ date: fmt(d), raw: m[0], kind: "relative" });
    }
  };
  rel(/\bhari ini\b/g, () => 0);
  rel(/\bbesok\b/g, () => 1);
  rel(/\blusa\b/g, () => 2);
  rel(/\b(\d+)\s*hari lagi\b/g, (m) => parseInt(m[1]));
  rel(/\bminggu depan\b/g, () => 7);
  rel(/\b(\d+)\s*minggu lagi\b/g, (m) => parseInt(m[1]) * 7);
  rel(/\bbulan depan\b/g, () => 0, () => 1);
  rel(/\b(\d+)\s*bulan lagi\b/g, () => 0, (m) => parseInt(m[1]));

  return out;
}

// ---------------------------------------------------------------------------
// Ekstraksi tugas dari percakapan
// ---------------------------------------------------------------------------

const GREETING_RE = /^(halo+|hai|hi|hello|selamat (pagi|siang|sore|malam)|permisi|ass?alamu[^\s]*|pagi|siang|sore|malam|tes|test)\b/i;

const TUJUAN_RULES: { re: RegExp; tujuan: string }[] = [
  { re: /skpd|surat ketetapan/, tujuan: "Penerbitan ulang / pengiriman salinan SKPD" },
  { re: /bayar|pembayaran|tagihan|billing|kode billing|stp|skpkb/, tujuan: "Penyelesaian pembayaran / tagihan pajak" },
  { re: /lapor|spt|pelaporan|input laporan/, tujuan: "Penyelesaian kendala pelaporan" },
  { re: /password|kata sandi|lupa sandi|akun|login|masuk aplikasi/, tujuan: "Pemulihan akses akun layanan" },
  { re: /npwpd|pendaftaran|daftar/, tujuan: "Pendaftaran NPWPD / data subjek pajak" },
  { re: /keberatan|banding|sengketa/, tujuan: "Penanganan keberatan / sengketa tagihan" },
  { re: /jatuh tempo|denda|sanksi|telat/, tujuan: "Klarifikasi jatuh tempo dan sanksi" },
];

const BEBAN_SULIT = /keberatan|banding|sengketa|audit|data hilang|sistem error|error sistem|gagal total|rusak|korup|tidak bisa sama sekali/i;
const BEBAN_SEDANG = /kendala|tidak bisa|gagal|lambat|lemot|salah (hitung|input|data)|verifikasi|minta (dicek|periksa)|belum (masuk|terbit|sampai)/i;

export const WAKTU_BY_HARI: { maxHari: number; label: string }[] = [
  { maxHari: 1, label: "1 hari" },
  { maxHari: 7, label: "> 1 hari" },
  { maxHari: 31, label: "> 7 hari" },
  { maxHari: 93, label: "> 1 bulan" },
  { maxHari: Infinity, label: "> 3 bulan" },
];

export function waktuFromHari(hari: number): string {
  return WAKTU_BY_HARI.find((w) => hari <= w.maxHari)!.label;
}

export interface ConvMessage {
  direction: "in" | "out";
  senderType: "contact" | "admin" | "bot";
  body: string;
  createdAt: Date;
}

export interface ExtractedDraft {
  pemohon: string;
  waNumber: string;
  tanggalPemohon: string;
  tanggalHarusSelesai: string;
  tugas: string;
  keterangan: string;
  masalah: string;
  caraPenyelesaian: string;
  tanggalJatuhTempo: string;
  tujuanTugas: string;
  beban: "ringan" | "sedang" | "sulit";
  waktuPenyelesaian: string;
  dasarAnalisis: { field: string; value: string; reason: string }[];
}

export function extractTaskDraft(params: {
  contactName: string;
  waNumber: string;
  messages: ConvMessage[];
  now: Date;
}): ExtractedDraft {
  const { contactName, waNumber, messages, now } = params;
  const inbound = messages.filter((m) => m.direction === "in");
  const outbound = messages.filter((m) => m.direction === "out");
  const alasan: ExtractedDraft["dasarAnalisis"] = [];
  const today = fmt(now);

  // --- Masalah: pesan pelanggan pertama yang bukan sekadar sapaan ---
  const substantive = inbound.filter((m) => !(m.body.trim().length < 30 && GREETING_RE.test(m.body.trim())));
  const masalahSrc = substantive.length ? substantive : inbound;
  const masalah = masalahSrc.slice(0, 2).map((m) => m.body.trim()).join(" — ").slice(0, 500);
  alasan.push({
    field: "Masalah",
    value: masalah || "(kosong)",
    reason: substantive.length
      ? "Diambil dari pesan pelanggan pertama yang berisi substansi (sapaan singkat dilewati)."
      : "Tidak ada pesan substansi; seluruh pesan pelanggan dipakai apa adanya.",
  });

  // --- Cara penyelesaian: balasan terakhir petugas/bot ---
  const lastOut = outbound[outbound.length - 1];
  const caraPenyelesaian = lastOut ? lastOut.body.trim().slice(0, 500) : "";
  alasan.push({
    field: "Cara Penyelesaian",
    value: caraPenyelesaian || "(belum ada balasan)",
    reason: lastOut
      ? `Ringkasan dari balasan terakhir ${lastOut.senderType === "admin" ? "petugas" : "bot"} pada percakapan.`
      : "Belum ada balasan apa pun di percakapan ini.",
  });

  // --- Tanggal jatuh tempo: HANYA dari pesan pelanggan (inbound).
  //     Tanggal eksplisit menang atas tanggal relatif; sebutan terakhir menang
  //     (koreksi pelanggan di akhir percakapan dianggap paling mutakhir).
  //     Pesan bot/petugas tidak dipindai agar tanggal dalam kalimat balasan
  //     tidak menimpa tanggal yang disebut pelanggan.
  let jatuhTempo = "";
  let jatuhTempoRaw = "";
  let jatuhTempoKind: "explicit" | "relative" | "" = "";
  for (const m of inbound) {
    for (const p of parseDates(m.body, now)) {
      if (p.kind === "explicit" || jatuhTempoKind !== "explicit") {
        // eksplisit selalu menimpa; relatif hanya menimpa relatif
        if (p.kind === "relative" && jatuhTempoKind === "explicit") continue;
        jatuhTempo = p.date;
        jatuhTempoRaw = p.raw;
        jatuhTempoKind = p.kind;
      }
    }
  }
  alasan.push({
    field: "Tanggal Jatuh Tempo",
    value: jatuhTempo || "(tidak disebut)",
    reason: jatuhTempo
      ? `Pelanggan menyebut "${jatuhTempoRaw}" (${jatuhTempoKind === "explicit" ? "tanggal eksplisit" : "tanggal relatif, dikonversi dari hari ini"}). Hanya pesan pelanggan yang dipindai.`
      : "Pelanggan tidak menyebut tanggal apa pun dalam pesannya.",
  });

  // --- Tujuan tugas dari kata kunci masalah pelanggan ---
  const inboundText = inbound.map((m) => m.body).join(" ");
  const tujuanHit = TUJUAN_RULES.find((r) => r.re.test(inboundText));
  const tujuanTugas = tujuanHit ? tujuanHit.tujuan : "Tindak lanjut permintaan pemohon";
  alasan.push({
    field: "Tujuan Tugas",
    value: tujuanTugas,
    reason: tujuanHit
      ? `Pesan pelanggan mengandung kata kunci /${tujuanHit.re.source}/.`
      : "Tidak ada kata kunci kategori yang cocok — diisi tujuan umum.",
  });

  // --- Beban: dinilai dari teks PELANGGAN saja (bukan teks bot) ---
  let beban: ExtractedDraft["beban"] = "ringan";
  let bebanReason = "Tidak ada indikator kesulitan pada pesan pelanggan — diasumsikan ringan.";
  if (BEBAN_SULIT.test(inboundText)) {
    beban = "sulit";
    bebanReason = `Pesan pelanggan mengandung indikator berat (/${BEBAN_SULIT.source}/).`;
  } else if (BEBAN_SEDANG.test(inboundText)) {
    beban = "sedang";
    bebanReason = `Pesan pelanggan mengandung indikator kendala (/${BEBAN_SEDANG.source}/).`;
  }
  alasan.push({ field: "Beban Tugas", value: beban, reason: bebanReason });

  // --- Waktu penyelesaian: dari jarak jatuh tempo bila ada, else dari beban ---
  let waktu: string;
  let waktuReason: string;
  if (jatuhTempo) {
    const diffHari = Math.max(
      0,
      Math.round((new Date(jatuhTempo).getTime() - new Date(today).getTime()) / 86400000)
    );
    waktu = waktuFromHari(diffHari);
    waktuReason = `Jatuh tempo ${diffHari} hari dari hari ini → kategori "${waktu}".`;
  } else {
    waktu = beban === "ringan" ? "1 hari" : beban === "sedang" ? "> 1 hari" : "> 7 hari";
    waktuReason = `Tanpa tanggal dari pelanggan, estimasi mengikuti beban "${beban}".`;
  }
  alasan.push({ field: "Waktu Penyelesaian", value: waktu, reason: waktuReason });

  // --- Tanggal pemohon: pesan pelanggan pertama ---
  const tanggalPemohon = inbound.length ? fmt(inbound[0].createdAt) : today;

  // --- Tanggal harus selesai (tenggat kerja internal):
  //     mengikuti jatuh tempo bila ada; bila tidak, dari kategori waktu.
  let harusSelesai = jatuhTempo;
  if (!harusSelesai) {
    const mapHari: Record<string, number> = {
      "1 hari": 1, "> 1 hari": 3, "> 7 hari": 14, "> 1 bulan": 45, "> 3 bulan": 120,
    };
    harusSelesai = fmt(addDays(now, mapHari[waktu] ?? 3));
  }
  alasan.push({
    field: "Tanggal Harus Selesai",
    value: harusSelesai,
    reason: jatuhTempo
      ? "Disamakan dengan tanggal jatuh tempo yang disebut pelanggan."
      : "Diisi dari estimasi kategori waktu penyelesaian (bisa dikoreksi).",
  });

  const tugas = masalah ? `Tindak lanjut: ${masalah.slice(0, 140)}` : "Tindak lanjut percakapan";
  const keterangan = `Direkam otomatis dari percakapan WhatsApp dengan ${contactName} (${waNumber}) pada ${today}.`;

  return {
    pemohon: contactName,
    waNumber,
    tanggalPemohon,
    tanggalHarusSelesai: harusSelesai,
    tugas,
    keterangan,
    masalah,
    caraPenyelesaian,
    tanggalJatuhTempo: jatuhTempo,
    tujuanTugas,
    beban,
    waktuPenyelesaian: waktu,
    dasarAnalisis: alasan,
  };
}
