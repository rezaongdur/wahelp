import { createRouter, publicQuery } from "./middleware";
import { whatsappRouter } from "./routers/whatsapp";
import { conversationsRouter } from "./routers/conversations";
import { tasksRouter } from "./routers/tasks";
import { botRouter } from "./routers/bot";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  whatsapp: whatsappRouter,
  conversations: conversationsRouter,
  tasks: tasksRouter,
  bot: botRouter,
});

export type AppRouter = typeof appRouter;
