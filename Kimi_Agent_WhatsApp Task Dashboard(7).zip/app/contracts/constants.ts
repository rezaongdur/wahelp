// Konstanta & tipe bersama antara frontend dan backend.
// Jangan impor dari api/ atau db/ di sini — file ini aman dipakai dua sisi.

export const TASK_STATUSES = ["baru", "diproses", "selesai"] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const TASK_STATUS_LABELS: Record<TaskStatus, string> = {
  baru: "Baru",
  diproses: "Diproses",
  selesai: "Selesai",
};

export const BEBAN_OPTIONS = ["ringan", "sedang", "sulit"] as const;
export type BebanTugas = (typeof BEBAN_OPTIONS)[number];

export const BEBAN_LABELS: Record<BebanTugas, string> = {
  ringan: "Ringan",
  sedang: "Sedang",
  sulit: "Sulit",
};

export const WAKTU_OPTIONS = [
  "1 hari",
  "> 1 hari",
  "> 7 hari",
  "> 1 bulan",
  "> 3 bulan",
] as const;
export type WaktuPenyelesaian = (typeof WAKTU_OPTIONS)[number];

export const SUMBER_OPTIONS = ["manual", "bot"] as const;
export type SumberTugas = (typeof SUMBER_OPTIONS)[number];

export const SUMBER_LABELS: Record<SumberTugas, string> = {
  manual: "Manual",
  bot: "Bot / Rekaman Percakapan",
};

export type TaskDraft = {
  pemohon: string;
  waNumber: string;
  tanggalPemohon: string; // YYYY-MM-DD
  tanggalHarusSelesai: string; // tenggat kerja internal
  tugas: string;
  keterangan: string;
  masalah: string;
  caraPenyelesaian: string;
  tanggalJatuhTempo: string; // tanggal yang disebut pelanggan
  tujuanTugas: string;
  beban: BebanTugas;
  waktuPenyelesaian: WaktuPenyelesaian;
  dasarAnalisis: { field: string; value: string; reason: string }[];
};

export const WA_SESSION_STATUS = [
  "disconnected",
  "waiting_scan",
  "connected",
] as const;
export type WaSessionStatus = (typeof WA_SESSION_STATUS)[number];

export const BOT_DECISIONS = [
  "auto_reply",
  "greeting",
  "fallback",
  "handoff",
  "off",
  "out_of_hours",
  "spam_skip",
] as const;
export type BotDecision = (typeof BOT_DECISIONS)[number];
