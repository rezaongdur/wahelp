import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Plus, Search, Pencil, Trash2, Eye, MessageSquareText, CircleAlert, Sparkles, ClipboardList,
} from "lucide-react";
import TaskFormDialog, { type TaskForForm } from "@/components/TaskFormDialog";
import RecordTaskDialog from "@/components/RecordTaskDialog";
import { BEBAN_OPTIONS, BEBAN_LABELS, TASK_STATUSES, TASK_STATUS_LABELS, SUMBER_OPTIONS, SUMBER_LABELS } from "@contracts/constants";
import { toast } from "sonner";

type TaskRow = TaskForForm & { today: string };

function diffDays(a: string, b: string) {
  return Math.round((new Date(a + "T00:00:00").getTime() - new Date(b + "T00:00:00").getTime()) / 86400000);
}

function DeadlineChip({ task }: { task: TaskRow }) {
  if (!task.tanggalHarusSelesai)
    return <span className="text-xs text-muted-foreground">—</span>;
  if (task.status === "selesai")
    return <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">tuntas</Badge>;
  const d = diffDays(task.tanggalHarusSelesai, task.today);
  if (d < 0)
    return <Badge variant="destructive">lewat {-d} hari</Badge>;
  if (d === 0)
    return <Badge className="bg-amber-500 hover:bg-amber-500">hari ini</Badge>;
  return <Badge variant="secondary" className="bg-emerald-100 text-emerald-800">{d} hari lagi</Badge>;
}

function StatusBadge({ status }: { status: keyof typeof TASK_STATUS_LABELS }) {
  const cls =
    status === "baru" ? "bg-sky-100 text-sky-800"
    : status === "diproses" ? "bg-amber-100 text-amber-800"
    : "bg-emerald-100 text-emerald-800";
  return <Badge variant="secondary" className={cls}>{TASK_STATUS_LABELS[status]}</Badge>;
}

const BEBAN_CLS: Record<string, string> = {
  ringan: "bg-emerald-100 text-emerald-800",
  sedang: "bg-amber-100 text-amber-800",
  sulit: "bg-red-100 text-red-800",
};

export default function TasksPage() {
  const utils = trpc.useUtils();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [beban, setBeban] = useState<string>("all");
  const [sumber, setSumber] = useState<string>("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<TaskRow | null>(null);
  const [detail, setDetail] = useState<TaskRow | null>(null);
  const [deleting, setDeleting] = useState<TaskRow | null>(null);
  const [pickOpen, setPickOpen] = useState(false);
  const [recordConvId, setRecordConvId] = useState<number | null>(null);

  const summary = trpc.tasks.summary.useQuery(undefined, { refetchInterval: 10000 });
  const list = trpc.tasks.list.useQuery(
    {
      q: q || undefined,
      status: status === "all" ? undefined : (status as "baru" | "diproses" | "selesai"),
      beban: beban === "all" ? undefined : (beban as "ringan" | "sedang" | "sulit"),
      sumber: sumber === "all" ? undefined : (sumber as "manual" | "bot"),
    },
    { refetchInterval: 10000 }
  );
  const convs = trpc.conversations.list.useQuery(undefined, { enabled: pickOpen });

  const remove = trpc.tasks.remove.useMutation({
    onSuccess: () => {
      utils.tasks.list.invalidate();
      utils.tasks.summary.invalidate();
      toast.success("Tugas dihapus.");
      setDeleting(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const cards = [
    { label: "Baru", value: summary.data?.baru ?? 0, cls: "text-sky-700" },
    { label: "Diproses", value: summary.data?.diproses ?? 0, cls: "text-amber-700" },
    { label: "Selesai", value: summary.data?.selesai ?? 0, cls: "text-emerald-700" },
    { label: "Terlambat", value: summary.data?.terlambat ?? 0, cls: "text-red-700" },
  ];

  let dasar: { field: string; value: string; reason: string }[] = [];
  if (detail?.dasarAnalisis) {
    try { dasar = JSON.parse(detail.dasarAnalisis); } catch { /* abaikan */ }
  }

  return (
    <div className="flex-1 space-y-5 overflow-y-auto p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Manajemen Tugas</h1>
          <p className="text-sm text-muted-foreground">
            Tugas dari permintaan pemohon di percakapan WhatsApp.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setPickOpen(true)}>
            <Sparkles className="mr-1.5 h-4 w-4" /> Rekam dari percakapan
          </Button>
          <Button onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Plus className="mr-1.5 h-4 w-4" /> Tambah tugas
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label}>
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{c.label}</div>
                <div className={cn("mt-1 text-2xl font-bold", c.cls)}>{c.value}</div>
              </div>
              {c.label === "Terlambat" && c.value > 0 && <CircleAlert className="h-5 w-5 text-red-500" />}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input className="pl-8" placeholder="Cari pemohon / tugas…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua status</SelectItem>
            {TASK_STATUSES.map((s) => <SelectItem key={s} value={s}>{TASK_STATUS_LABELS[s]}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={beban} onValueChange={setBeban}>
          <SelectTrigger className="w-36"><SelectValue placeholder="Beban" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua beban</SelectItem>
            {BEBAN_OPTIONS.map((b) => <SelectItem key={b} value={b}>{BEBAN_LABELS[b]}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={sumber} onValueChange={setSumber}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Sumber" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua sumber</SelectItem>
            {SUMBER_OPTIONS.map((s) => <SelectItem key={s} value={s}>{SUMBER_LABELS[s]}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Pemohon</TableHead>
              <TableHead className="w-[34%]">Tugas</TableHead>
              <TableHead>Tenggat Kerja</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Beban</TableHead>
              <TableHead>Sumber</TableHead>
              <TableHead className="text-right">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {(list.data ?? []).length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">
                  <ClipboardList className="mx-auto mb-2 h-8 w-8 opacity-30" />
                  Tidak ada tugas yang cocok dengan filter.
                </TableCell>
              </TableRow>
            )}
            {(list.data ?? []).map((t) => (
              <TableRow key={t.id}>
                <TableCell>
                  <div className="text-sm font-medium">{t.pemohon}</div>
                  {t.waNumber && <div className="text-xs text-muted-foreground">+{t.waNumber}</div>}
                </TableCell>
                <TableCell>
                  <div className="line-clamp-2 text-sm">{t.tugas}</div>
                  <div className="text-xs text-muted-foreground">diajukan {t.tanggalPemohon}</div>
                </TableCell>
                <TableCell>
                  <DeadlineChip task={t} />
                  {t.tanggalHarusSelesai && (
                    <div className="mt-0.5 text-xs text-muted-foreground">{t.tanggalHarusSelesai}</div>
                  )}
                </TableCell>
                <TableCell><StatusBadge status={t.status} /></TableCell>
                <TableCell>
                  {t.beban ? (
                    <Badge variant="secondary" className={BEBAN_CLS[t.beban]}>{BEBAN_LABELS[t.beban]}</Badge>
                  ) : <span className="text-xs text-muted-foreground">—</span>}
                </TableCell>
                <TableCell>
                  <span className="text-xs text-muted-foreground">{SUMBER_LABELS[t.sumber]}</span>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button size="icon" variant="ghost" title="Detail" onClick={() => setDetail(t)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" title="Edit" onClick={() => { setEditing(t); setFormOpen(true); }}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    {t.conversationId && (
                      <Button
                        size="icon" variant="ghost" title="Lompat ke percakapan"
                        onClick={() => navigate(`/?c=${t.conversationId}`)}
                      >
                        <MessageSquareText className="h-4 w-4" />
                      </Button>
                    )}
                    <Button size="icon" variant="ghost" title="Hapus" onClick={() => setDeleting(t)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Form tambah/edit */}
      <TaskFormDialog open={formOpen} onOpenChange={setFormOpen} task={editing} />

      {/* Dialog pilih percakapan untuk direkam */}
      <Dialog open={pickOpen} onOpenChange={setPickOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Rekam tugas dari percakapan</DialogTitle>
            <DialogDescription>Pilih percakapan yang ingin dianalisis dan direkam menjadi tugas.</DialogDescription>
          </DialogHeader>
          <div className="max-h-80 space-y-1 overflow-y-auto">
            {(convs.data ?? []).map((c) => (
              <button
                key={c.id}
                className="flex w-full items-center justify-between rounded-lg border px-3 py-2.5 text-left text-sm hover:bg-accent"
                onClick={() => { setPickOpen(false); setRecordConvId(c.id); }}
              >
                <div>
                  <div className="font-medium">{c.contactName}</div>
                  <div className="truncate text-xs text-muted-foreground">{c.lastMessagePreview}</div>
                </div>
                {c.status === "resolved" && <Badge variant="outline">selesai</Badge>}
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {recordConvId != null && (
        <RecordTaskDialog
          conversationId={recordConvId}
          open={recordConvId != null}
          onOpenChange={(o) => { if (!o) setRecordConvId(null); }}
        />
      )}

      {/* Detail tugas */}
      <Dialog open={detail != null} onOpenChange={(o) => { if (!o) setDetail(null); }}>
        <DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detail tugas #{detail?.id}</DialogTitle>
            <DialogDescription>{detail?.tugas}</DialogDescription>
          </DialogHeader>
          {detail && (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                <Field label="Pemohon" value={detail.pemohon} />
                <Field label="No. WhatsApp" value={detail.waNumber ? `+${detail.waNumber}` : "—"} />
                <Field label="Tanggal Pemohon" value={detail.tanggalPemohon} />
                <Field label="Tanggal Harus Selesai (tenggat kerja)" value={detail.tanggalHarusSelesai ?? "—"} />
                <Field label="Status" value={TASK_STATUS_LABELS[detail.status]} />
                <Field label="Sumber" value={SUMBER_LABELS[detail.sumber]} />
              </div>
              {detail.keterangan && <Field label="Keterangan" value={detail.keterangan} />}

              {(detail.masalah || detail.beban) && (
                <div className="space-y-2 rounded-lg border border-primary/25 bg-accent/50 p-3">
                  <div className="text-xs font-semibold uppercase tracking-wide text-primary">Rekaman percakapan</div>
                  <Field label="Masalah" value={detail.masalah ?? "—"} />
                  <Field label="Cara Penyelesaian" value={detail.caraPenyelesaian ?? "—"} />
                  <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                    <Field label="Tanggal Jatuh Tempo (pelanggan)" value={detail.tanggalJatuhTempo ?? "—"} />
                    <Field label="Tujuan Tugas" value={detail.tujuanTugas ?? "—"} />
                    <Field label="Beban" value={detail.beban ? BEBAN_LABELS[detail.beban] : "—"} />
                    <Field label="Waktu Penyelesaian" value={detail.waktuPenyelesaian ?? "—"} />
                  </div>
                </div>
              )}

              {dasar.length > 0 && (
                <div className="rounded-lg border bg-muted/50 p-3">
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Dasar analisis otomatis
                  </div>
                  <ul className="space-y-1.5 text-xs">
                    {dasar.map((d, i) => (
                      <li key={i}>
                        <span className="font-medium">{d.field}</span>
                        <span className="text-muted-foreground"> — {d.reason}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            {detail?.conversationId && (
              <Button variant="outline" onClick={() => { setDetail(null); navigate(`/?c=${detail.conversationId}`); }}>
                <MessageSquareText className="mr-1.5 h-4 w-4" /> Buka percakapan
              </Button>
            )}
            <Button onClick={() => setDetail(null)}>Tutup</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Hapus */}
      <AlertDialog open={deleting != null} onOpenChange={(o) => { if (!o) setDeleting(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus tugas ini?</AlertDialogTitle>
            <AlertDialogDescription>
              Tugas "{deleting?.tugas.slice(0, 80)}" akan dihapus permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => deleting && remove.mutate({ id: deleting.id })}
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="whitespace-pre-wrap font-medium">{value}</div>
    </div>
  );
}
