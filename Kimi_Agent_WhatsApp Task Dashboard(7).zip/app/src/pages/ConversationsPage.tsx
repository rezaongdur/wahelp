import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import {
  Bot, ClipboardCheck, HandMetal, SendHorizonal, Search, FlaskConical, UserRound,
} from "lucide-react";
import RecordTaskDialog from "@/components/RecordTaskDialog";
import { toast } from "sonner";

function fmtTime(d: Date | string) {
  const dt = new Date(d);
  return dt.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}
function fmtDay(d: Date | string) {
  const dt = new Date(d);
  return dt.toLocaleDateString("id-ID", { day: "numeric", month: "short" });
}
function initials(name: string) {
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() ?? "").join("");
}

export default function ConversationsPage() {
  const utils = trpc.useUtils();
  const [params, setParams] = useSearchParams();
  const [selectedId, setSelectedId] = useState<number | null>(
    params.get("c") ? Number(params.get("c")) : null
  );
  const [search, setSearch] = useState("");
  const [draftMsg, setDraftMsg] = useState("");
  const [recordOpen, setRecordOpen] = useState(false);
  const [simOpen, setSimOpen] = useState(false);
  const [simText, setSimText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const list = trpc.conversations.list.useQuery(undefined, { refetchInterval: 4000 });
  const detail = trpc.conversations.detail.useQuery(
    { id: selectedId! },
    { enabled: selectedId != null, refetchInterval: 3000 }
  );
  const botSettings = trpc.bot.getSettings.useQuery(undefined, { refetchInterval: 20000 });

  const sendMessage = trpc.conversations.sendMessage.useMutation({
    onSuccess: () => {
      setDraftMsg("");
      utils.conversations.detail.invalidate({ id: selectedId! });
      utils.conversations.list.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const setBotState = trpc.conversations.setBotState.useMutation({
    onSuccess: () => {
      utils.conversations.detail.invalidate({ id: selectedId! });
      utils.conversations.list.invalidate();
    },
  });
  const markRead = trpc.conversations.markRead.useMutation();
  const simulate = trpc.whatsapp.simulateInbound.useMutation({
    onSuccess: (r) => {
      setSimText("");
      utils.conversations.detail.invalidate({ id: selectedId! });
      utils.conversations.list.invalidate();
      utils.bot.logs.invalidate();
      toast.success(
        r.botReplied ? "Pesan masuk diterima — bot membalas otomatis." : `Pesan masuk diterima (keputusan bot: ${r.decision}).`
      );
    },
    onError: (e) => toast.error(e.message),
  });

  // Buka percakapan dari halaman tugas (/?c=ID)
  useEffect(() => {
    const c = params.get("c");
    if (c) {
      setSelectedId(Number(c));
      params.delete("c");
      setParams(params, { replace: true });
    }
  }, [params, setParams]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [detail.data?.messages.length, selectedId]);

  useEffect(() => {
    if (selectedId != null && detail.data?.conversation.unreadCount) {
      markRead.mutate({ conversationId: selectedId });
      utils.conversations.list.invalidate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId, detail.data?.conversation.unreadCount]);

  const conv = detail.data?.conversation;
  const contact = detail.data?.contact;
  const messages = detail.data?.messages ?? [];
  const filtered = (list.data ?? []).filter(
    (c) =>
      !search ||
      c.contactName.toLowerCase().includes(search.toLowerCase()) ||
      c.waNumber.includes(search)
  );

  return (
    <div className="flex min-h-0 flex-1">
      {/* Panel kiri: daftar percakapan */}
      <div className="flex w-72 shrink-0 flex-col border-r bg-card">
        <div className="border-b p-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Cari nama / nomor…"
              className="pl-8"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {filtered.length === 0 && (
            <div className="p-6 text-center text-sm text-muted-foreground">Belum ada percakapan.</div>
          )}
          {filtered.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedId(c.id)}
              className={cn(
                "flex w-full items-start gap-3 border-b px-3 py-3 text-left transition-colors hover:bg-accent/60",
                selectedId === c.id && "bg-accent"
              )}
            >
              <Avatar className="h-10 w-10 shrink-0">
                <AvatarFallback className="bg-primary/10 text-xs font-semibold text-primary">
                  {initials(c.contactName)}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-sm font-medium">{c.contactName}</span>
                  <span className="shrink-0 text-[11px] text-muted-foreground">
                    {c.lastMessageAt ? fmtDay(c.lastMessageAt) : ""}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-xs text-muted-foreground">
                    {c.lastMessagePreview ?? "—"}
                  </span>
                  <span className="flex shrink-0 items-center gap-1">
                    {c.botState === "active" ? (
                      <Bot className="h-3.5 w-3.5 text-primary" />
                    ) : (
                      <UserRound className="h-3.5 w-3.5 text-amber-600" />
                    )}
                    {c.unreadCount > 0 && (
                      <span className="rounded-full bg-primary px-1.5 text-[10px] font-bold text-primary-foreground">
                        {c.unreadCount}
                      </span>
                    )}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Panel tengah: jendela chat */}
      <div className="flex min-w-0 flex-1 flex-col bg-[#efeae2]">
        {conv && contact ? (
          <>
            <div className="flex items-center justify-between gap-3 border-b bg-card px-4 py-2.5">
              <div className="flex min-w-0 items-center gap-3">
                <Avatar className="h-9 w-9">
                  <AvatarFallback className="bg-primary/10 text-xs font-semibold text-primary">
                    {initials(contact.name)}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <div className="truncate text-sm font-semibold">{contact.name}</div>
                  <div className="text-xs text-muted-foreground">+{contact.waNumber}</div>
                </div>
                <Badge
                  variant="secondary"
                  className={cn(
                    "ml-1",
                    conv.botState === "active"
                      ? "bg-emerald-100 text-emerald-800"
                      : "bg-amber-100 text-amber-800"
                  )}
                >
                  {conv.botState === "active" ? "Bot aktif" : "Ditangani admin"}
                </Badge>
                {conv.status === "resolved" && <Badge variant="outline">Selesai</Badge>}
              </div>
              <div className="flex shrink-0 items-center gap-2">
                {conv.botState === "active" ? (
                  <Button
                    variant="outline" size="sm"
                    onClick={() => setBotState.mutate({ conversationId: conv.id, state: "handoff" })}
                  >
                    <HandMetal className="mr-1.5 h-4 w-4" /> Ambil alih
                  </Button>
                ) : (
                  <Button
                    variant="outline" size="sm"
                    onClick={() => setBotState.mutate({ conversationId: conv.id, state: "active" })}
                  >
                    <Bot className="mr-1.5 h-4 w-4" /> Aktifkan bot lagi
                  </Button>
                )}
                <Button size="sm" onClick={() => setRecordOpen(true)}>
                  <ClipboardCheck className="mr-1.5 h-4 w-4" /> Selesaikan & rekam tugas
                </Button>
              </div>
            </div>

            {!botSettings.data?.enabled && (
              <div className="border-b bg-amber-50 px-4 py-2 text-xs text-amber-800">
                Bot AI sedang <b>nonaktif</b> secara global — tidak ada balasan otomatis. Aktifkan di menu{" "}
                <b>Bot AI Helpdesk</b>.
              </div>
            )}

            <div className="flex-1 space-y-2 overflow-y-auto px-6 py-4">
              {messages.map((m) => (
                <div key={m.id} className={cn("flex", m.direction === "out" ? "justify-end" : "justify-start")}>
                  <div
                    className={cn(
                      "max-w-[72%] rounded-xl px-3 py-2 text-sm shadow-sm",
                      m.direction === "in"
                        ? "rounded-tl-sm bg-white"
                        : m.senderType === "bot"
                          ? "rounded-tr-sm bg-[#d9fdd3] ring-1 ring-primary/20"
                          : "rounded-tr-sm bg-[#d9fdd3]"
                    )}
                  >
                    {m.senderType === "bot" && (
                      <div className="mb-0.5 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-primary">
                        <Bot className="h-3 w-3" /> Balasan otomatis bot
                      </div>
                    )}
                    <div className="whitespace-pre-wrap break-words">{m.body}</div>
                    <div className="mt-0.5 text-right text-[10px] text-muted-foreground">{fmtTime(m.createdAt)}</div>
                  </div>
                </div>
              ))}
              <div ref={bottomRef} />
            </div>

            <form
              className="flex items-center gap-2 border-t bg-card px-4 py-3"
              onSubmit={(e) => {
                e.preventDefault();
                if (!draftMsg.trim()) return;
                sendMessage.mutate({ conversationId: conv.id, body: draftMsg.trim() });
              }}
            >
              <Input
                placeholder="Ketik balasan sebagai petugas… (bot otomatis diam setelah Anda membalas)"
                value={draftMsg}
                onChange={(e) => setDraftMsg(e.target.value)}
              />
              <Button type="submit" size="icon" disabled={sendMessage.isPending || !draftMsg.trim()}>
                <SendHorizonal className="h-4 w-4" />
              </Button>
            </form>
          </>
        ) : (
          <div className="flex flex-1 flex-col items-center justify-center gap-2 text-muted-foreground">
            <Bot className="h-10 w-10 opacity-30" />
            <p className="text-sm">Pilih percakapan di sebelah kiri.</p>
          </div>
        )}
      </div>

      {/* Panel kanan: info kontak */}
      {conv && contact && (
        <div className="flex w-64 shrink-0 flex-col gap-4 overflow-y-auto border-l bg-card p-4">
          <div className="flex flex-col items-center gap-2 pt-2 text-center">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="bg-primary/10 text-lg font-semibold text-primary">
                {initials(contact.name)}
              </AvatarFallback>
            </Avatar>
            <div className="font-semibold">{contact.name}</div>
            <div className="text-xs text-muted-foreground">+{contact.waNumber}</div>
          </div>
          <Separator />
          <div className="space-y-1 text-xs">
            <div className="font-semibold uppercase tracking-wide text-muted-foreground">Penanganan</div>
            <div className="flex justify-between py-0.5">
              <span className="text-muted-foreground">Mode</span>
              <span className="font-medium">{conv.botState === "active" ? "Bot AI" : "Petugas"}</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span className="text-muted-foreground">Status</span>
              <span className="font-medium">{conv.status === "open" ? "Terbuka" : "Selesai"}</span>
            </div>
          </div>
          <Button size="sm" variant="outline" onClick={() => setRecordOpen(true)}>
            <ClipboardCheck className="mr-1.5 h-4 w-4" /> Rekam tugas
          </Button>
          <Separator />
          <div className="space-y-2">
            <button
              className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground"
              onClick={() => setSimOpen((v) => !v)}
            >
              <FlaskConical className="h-3.5 w-3.5" /> Simulasi pesan masuk
            </button>
            {simOpen && (
              <form
                className="space-y-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!simText.trim()) return;
                  simulate.mutate({ waNumber: contact.waNumber, contactName: contact.name, body: simText.trim() });
                }}
              >
                <p className="text-[11px] leading-snug text-muted-foreground">
                  Menyuntikkan pesan seolah-olah dari pelanggan ini (menggantikan webhook pada mode demo).
                </p>
                <Input
                  placeholder="mis. kode billing saya gagal dibuat"
                  value={simText}
                  onChange={(e) => setSimText(e.target.value)}
                />
                <Button type="submit" size="sm" variant="secondary" className="w-full" disabled={simulate.isPending}>
                  Kirim sebagai pelanggan
                </Button>
              </form>
            )}
          </div>
        </div>
      )}

      {selectedId != null && (
        <RecordTaskDialog
          conversationId={selectedId}
          open={recordOpen}
          onOpenChange={setRecordOpen}
        />
      )}
    </div>
  );
}
