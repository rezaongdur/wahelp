import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { QrCode, Smartphone, Unplug, RefreshCw, Webhook, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

export default function SettingsPage() {
  const utils = trpc.useUtils();
  const status = trpc.whatsapp.status.useQuery(undefined, { refetchInterval: 4000 });
  const connect = trpc.whatsapp.connect.useMutation({
    onSuccess: () => utils.whatsapp.status.invalidate(),
    onError: (e) => toast.error(e.message),
  });
  const simulateScan = trpc.whatsapp.simulateScan.useMutation({
    onSuccess: () => {
      utils.whatsapp.status.invalidate();
      toast.success("Perangkat terhubung (mode demo).");
    },
    onError: (e) => toast.error(e.message),
  });
  const disconnect = trpc.whatsapp.disconnect.useMutation({
    onSuccess: () => {
      utils.whatsapp.status.invalidate();
      toast.success("Sesi WhatsApp diputus.");
    },
  });

  const s = status.data;

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="mx-auto max-w-3xl space-y-6">
        <div>
          <h1 className="text-xl font-semibold">Koneksi WhatsApp</h1>
          <p className="text-sm text-muted-foreground">
            Hubungkan akun WhatsApp layanan dengan memindai kode QR — sama seperti WhatsApp Web.
          </p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base">Status perangkat</CardTitle>
                <CardDescription>
                  {s?.status === "connected"
                    ? "Perangkat terhubung dan siap menerima/mengirim pesan."
                    : s?.status === "waiting_scan"
                      ? "Pindai kode QR di bawah dengan WhatsApp di ponsel Anda."
                      : "Belum ada perangkat yang terhubung."}
                </CardDescription>
              </div>
              <Badge
                variant={s?.status === "connected" ? "default" : "secondary"}
                className={s?.status === "connected" ? "bg-emerald-600 hover:bg-emerald-600" : ""}
              >
                {s?.status === "connected" ? "Terhubung" : s?.status === "waiting_scan" ? "Menunggu pindaian" : "Terputus"}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {s?.status === "connected" && (
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">
                    <Smartphone className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-medium">{s.pushName ?? "Perangkat WhatsApp"}</div>
                    <div className="text-sm text-muted-foreground">+{s.phoneNumber}</div>
                  </div>
                </div>
                <Button variant="outline" onClick={() => disconnect.mutate()} disabled={disconnect.isPending}>
                  <Unplug className="mr-2 h-4 w-4" /> Putuskan
                </Button>
              </div>
            )}

            {s?.status === "waiting_scan" && (
              <div className="flex flex-col items-center gap-4 py-2">
                {s.qrDataUrl ? (
                  <img src={s.qrDataUrl} alt="Kode QR WhatsApp" className="h-64 w-64 rounded-lg border" />
                ) : (
                  <div className="flex h-64 w-64 items-center justify-center rounded-lg border text-muted-foreground">
                    Memuat QR…
                  </div>
                )}
                <ol className="list-decimal space-y-1 text-sm text-muted-foreground">
                  <li>Buka WhatsApp di ponsel → <b>Pengaturan → Perangkat Tertaut</b>.</li>
                  <li>Pilih <b>Tautkan Perangkat</b>, lalu arahkan kamera ke kode ini.</li>
                </ol>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => connect.mutate()} disabled={connect.isPending}>
                    <RefreshCw className="mr-2 h-4 w-4" /> Buat ulang QR
                  </Button>
                  <Button size="sm" onClick={() => simulateScan.mutate()} disabled={simulateScan.isPending}>
                    Simulasikan pemindaian (demo)
                  </Button>
                </div>
              </div>
            )}

            {(!s || s.status === "disconnected") && (
              <div className="flex flex-col items-center gap-4 py-6">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-accent text-primary">
                  <QrCode className="h-8 w-8" />
                </div>
                <Button onClick={() => connect.mutate()} disabled={connect.isPending}>
                  <QrCode className="mr-2 h-4 w-4" /> Tampilkan kode QR
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Webhook className="h-4 w-4" /> Integrasi produksi
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <p>
              Di lingkungan demo ini, pemindaian QR disimulasikan. Untuk produksi, sambungkan gateway WhatsApp Anda:
            </p>
            <ul className="list-disc space-y-1.5 pl-5">
              <li>
                <b>Meta WhatsApp Business API</b> — daftarkan webhook ke{" "}
                <code className="rounded bg-muted px-1.5 py-0.5 text-xs">/api/webhook/whatsapp</code> dengan token verifikasi{" "}
                <code className="rounded bg-muted px-1.5 py-0.5 text-xs">wa-helpdesk-verify</code> (atur lewat env{" "}
                <code className="rounded bg-muted px-1.5 py-0.5 text-xs">WA_VERIFY_TOKEN</code>). Pesan masuk langsung
                memicu balasan bot.
              </li>
              <li>
                <b>Gateway QR pihak ketiga</b> — arahkan event pesan masuk ke endpoint webhook yang sama dengan format{" "}
                <code className="rounded bg-muted px-1.5 py-0.5 text-xs">{"{ waNumber, body, contactName }"}</code>.
              </li>
            </ul>
            <p className="flex items-start gap-2 rounded-lg bg-muted/60 p-3 text-xs">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              Webhook membalas Meta dalam hitungan milidetik; penyimpanan pesan dan balasan bot berjalan di latar
              belakang sehingga webhook tidak pernah terblokir.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
