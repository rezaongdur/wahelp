import { useEffect, useState } from "react";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Bot, Plus, Pencil, Trash2, FlaskConical, Power, TriangleAlert,
} from "lucide-react";
import { toast } from "sonner";

const HARI = ["", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];

const DECISION_LABELS: Record<string, string> = {
  auto_reply: "Balasan otomatis",
  greeting: "Sapaan kontak baru",
  fallback: "Balasan cadangan",
  handoff: "Alihkan ke petugas",
  off: "Bot nonaktif",
  out_of_hours: "Di luar jam layanan",
  spam_skip: "Dilewati (anti-spam)",
};

const DECISION_CLS: Record<string, string> = {
  auto_reply: "bg-emerald-100 text-emerald-800",
  greeting: "bg-sky-100 text-sky-800",
  fallback: "bg-amber-100 text-amber-800",
  handoff: "bg-violet-100 text-violet-800",
  off: "bg-muted text-muted-foreground",
  out_of_hours: "bg-muted text-muted-foreground",
  spam_skip: "bg-muted text-muted-foreground",
};

interface KbForm {
  id?: number;
  title: string;
  keywordsText: string;
  answer: string;
}

export default function BotPage() {
  const utils = trpc.useUtils();
  const settings = trpc.bot.getSettings.useQuery(undefined, { refetchInterval: 20000 });
  const kb = trpc.bot.kbList.useQuery(undefined, { refetchInterval: 15000 });
  const logs = trpc.bot.logs.useQuery({ limit: 50 }, { refetchInterval: 8000 });

  const [kbForm, setKbForm] = useState<KbForm | null>(null);
  const [testInput, setTestInput] = useState("");
  const [testNew, setTestNew] = useState(false);
  const [testRun, setTestRun] = useState<{ input: string; isNewContact: boolean } | null>(null);

  // Form pengaturan
  const [form, setForm] = useState({
    greetingMessage: "", fallbackMessage: "", handoffText: "",
    hoursStart: "08:00", hoursEnd: "16:00", workDays: [1, 2, 3, 4, 5] as number[],
    antiSpamSeconds: 20,
  });
  useEffect(() => {
    const s = settings.data;
    if (s) {
      setForm({
        greetingMessage: s.greetingMessage,
        fallbackMessage: s.fallbackMessage,
        handoffText: s.handoffKeywords.join("\n"),
        hoursStart: s.hoursStart,
        hoursEnd: s.hoursEnd,
        workDays: s.workDays,
        antiSpamSeconds: s.antiSpamSeconds,
      });
    }
  }, [settings.data]);

  const testResult = trpc.bot.test.useQuery(testRun!, { enabled: testRun != null });

  const toggle = trpc.bot.updateSettings.useMutation({
    onSuccess: () => utils.bot.getSettings.invalidate(),
    onError: (e) => toast.error(e.message),
  });
  const saveSettings = trpc.bot.updateSettings.useMutation({
    onSuccess: () => { utils.bot.getSettings.invalidate(); toast.success("Pengaturan bot disimpan."); },
    onError: (e) => toast.error(e.message),
  });
  const kbCreate = trpc.bot.kbCreate.useMutation({
    onSuccess: () => { utils.bot.kbList.invalidate(); toast.success("Entri ditambahkan."); setKbForm(null); },
    onError: (e) => toast.error(e.message),
  });
  const kbUpdate = trpc.bot.kbUpdate.useMutation({
    onSuccess: () => { utils.bot.kbList.invalidate(); toast.success("Entri diperbarui."); setKbForm(null); },
    onError: (e) => toast.error(e.message),
  });
  const kbDelete = trpc.bot.kbDelete.useMutation({
    onSuccess: () => { utils.bot.kbList.invalidate(); toast.success("Entri dihapus."); },
    onError: (e) => toast.error(e.message),
  });

  const enabled = settings.data?.enabled ?? false;

  const saveKb = () => {
    if (!kbForm) return;
    const keywords = kbForm.keywordsText.split("\n").map((s) => s.trim()).filter(Boolean);
    if (!kbForm.title.trim() || !keywords.length || !kbForm.answer.trim()) {
      toast.error("Judul, minimal 1 kata kunci, dan jawaban wajib diisi.");
      return;
    }
    if (kbForm.id) kbUpdate.mutate({ id: kbForm.id, title: kbForm.title, keywords, answer: kbForm.answer });
    else kbCreate.mutate({ title: kbForm.title, keywords, answer: kbForm.answer, sortOrder: (kb.data?.length ?? 0) + 1 });
  };

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="mx-auto max-w-5xl space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="flex items-center gap-2 text-xl font-semibold">
              <Bot className="h-5 w-5 text-primary" /> Bot AI Agent Helpdesk
            </h1>
            <p className="text-sm text-muted-foreground">
              Balasan otomatis berbasis aturan & kata kunci — tanpa API AI berbayar.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">{enabled ? "Aktif" : "Nonaktif"}</span>
            <Switch checked={enabled} onCheckedChange={(v) => toggle.mutate({ enabled: v })} />
          </div>
        </div>

        {!enabled && (
          <Card className="border-amber-300 bg-amber-50">
            <CardContent className="flex items-center justify-between gap-4 p-4">
              <div className="flex items-start gap-3">
                <TriangleAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
                <div className="text-sm text-amber-900">
                  <b>Bot sedang NONAKTIF.</b> Tidak ada pesan otomatis apa pun yang dikirim ke pelanggan.
                  Aktifkan hanya setelah Anda meninjau basis pengetahuan dan pengaturan.
                </div>
              </div>
              <Button size="sm" onClick={() => toggle.mutate({ enabled: true })} disabled={toggle.isPending}>
                <Power className="mr-1.5 h-4 w-4" /> Aktifkan bot
              </Button>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="kb">
          <TabsList>
            <TabsTrigger value="kb">Basis Pengetahuan</TabsTrigger>
            <TabsTrigger value="pengaturan">Pengaturan</TabsTrigger>
            <TabsTrigger value="uji">Uji & Log</TabsTrigger>
          </TabsList>

          {/* ================= BASIS PENGETAHUAN ================= */}
          <TabsContent value="kb" className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Jawaban dipilih dari entri dengan skor kata kunci tertinggi. Kelola sendiri isinya di sini.
              </p>
              <Button size="sm" onClick={() => setKbForm({ title: "", keywordsText: "", answer: "" })}>
                <Plus className="mr-1.5 h-4 w-4" /> Tambah entri
              </Button>
            </div>
            <div className="space-y-2">
              {(kb.data ?? []).map((e) => (
                <Card key={e.id} className={cn(!e.enabled && "opacity-55")}>
                  <CardContent className="flex items-start justify-between gap-4 p-4">
                    <div className="min-w-0 flex-1">
                      <div className="font-medium">{e.title}</div>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {e.keywords.map((k) => (
                          <Badge key={k} variant="secondary" className="text-[11px]">{k}</Badge>
                        ))}
                      </div>
                      <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{e.answer}</p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <Switch
                        checked={e.enabled}
                        onCheckedChange={(v) => kbUpdate.mutate({ id: e.id, enabled: v })}
                      />
                      <Button
                        size="icon" variant="ghost"
                        onClick={() => setKbForm({ id: e.id, title: e.title, keywordsText: e.keywords.join("\n"), answer: e.answer })}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon" variant="ghost"
                        onClick={() => { if (confirm(`Hapus entri "${e.title}"?`)) kbDelete.mutate({ id: e.id }); }}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* ================= PENGATURAN ================= */}
          <TabsContent value="pengaturan">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Perilaku bot</CardTitle>
                <CardDescription>
                  Sapaan kontak baru, balasan cadangan, batas jam & hari layanan, jeda anti-spam, dan kata kunci
                  alihkan ke petugas.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1.5">
                  <Label>Sapaan untuk kontak baru</Label>
                  <Textarea rows={3} value={form.greetingMessage} onChange={(e) => setForm({ ...form, greetingMessage: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Balasan cadangan (bila tidak ada kecocokan)</Label>
                  <Textarea rows={3} value={form.fallbackMessage} onChange={(e) => setForm({ ...form, fallbackMessage: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label>Kata kunci alihkan ke petugas (satu per baris)</Label>
                  <Textarea rows={3} value={form.handoffText} onChange={(e) => setForm({ ...form, handoffText: e.target.value })} />
                  <p className="text-xs text-muted-foreground">
                    Bila pelanggan menulis salah satu kata kunci ini, bot menyerahkan percakapan ke petugas dan berhenti membalas.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
                  <div className="space-y-1.5">
                    <Label>Jam layanan mulai</Label>
                    <Input type="time" value={form.hoursStart} onChange={(e) => setForm({ ...form, hoursStart: e.target.value })} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Jam layanan selesai</Label>
                    <Input type="time" value={form.hoursEnd} onChange={(e) => setForm({ ...form, hoursEnd: e.target.value })} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Jeda anti-spam (detik)</Label>
                    <Input
                      type="number" min={0} max={3600}
                      value={form.antiSpamSeconds}
                      onChange={(e) => setForm({ ...form, antiSpamSeconds: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>Hari layanan</Label>
                  <div className="flex flex-wrap gap-3">
                    {[1, 2, 3, 4, 5, 6, 7].map((d) => (
                      <label key={d} className="flex items-center gap-1.5 text-sm">
                        <Checkbox
                          checked={form.workDays.includes(d)}
                          onCheckedChange={(v) =>
                            setForm({
                              ...form,
                              workDays: v === true ? [...form.workDays, d].sort() : form.workDays.filter((x) => x !== d),
                            })
                          }
                        />
                        {HARI[d]}
                      </label>
                    ))}
                  </div>
                </div>
                <Button
                  onClick={() =>
                    saveSettings.mutate({
                      greetingMessage: form.greetingMessage,
                      fallbackMessage: form.fallbackMessage,
                      handoffKeywords: form.handoffText.split("\n").map((s) => s.trim()).filter(Boolean),
                      hoursStart: form.hoursStart,
                      hoursEnd: form.hoursEnd,
                      workDays: form.workDays,
                      antiSpamSeconds: form.antiSpamSeconds,
                    })
                  }
                  disabled={saveSettings.isPending}
                >
                  Simpan pengaturan
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ================= UJI & LOG ================= */}
          <TabsContent value="uji" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <FlaskConical className="h-4 w-4" /> Uji balasan (tanpa mengirim)
                </CardTitle>
                <CardDescription>
                  Lihat apa yang akan dijawab bot, skor kecocokan, dan kandidatnya — tanpa mengirim pesan ke siapa pun.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <form
                  className="flex items-center gap-2"
                  onSubmit={(e) => { e.preventDefault(); if (testInput.trim()) setTestRun({ input: testInput.trim(), isNewContact: testNew }); }}
                >
                  <Input
                    placeholder="mis. bagaimana cara bayar pajak?"
                    value={testInput}
                    onChange={(e) => setTestInput(e.target.value)}
                  />
                  <label className="flex shrink-0 items-center gap-1.5 text-xs text-muted-foreground">
                    <Checkbox checked={testNew} onCheckedChange={(v) => setTestNew(v === true)} />
                    kontak baru
                  </label>
                  <Button type="submit" size="sm" disabled={testResult.isFetching}>Uji</Button>
                </form>

                {testResult.data && testRun && (
                  <div className="space-y-3 rounded-lg border bg-muted/40 p-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="secondary" className={DECISION_CLS[testResult.data.decision]}>
                        {DECISION_LABELS[testResult.data.decision]}
                      </Badge>
                      {testResult.data.matchedTitle && (
                        <span className="text-sm">cocok: <b>{testResult.data.matchedTitle}</b> (skor {testResult.data.score})</span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{testResult.data.reason}</p>
                    {testResult.data.replyText && (
                      <div className="rounded-lg bg-[#d9fdd3] p-3 text-sm">
                        <div className="mb-1 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-primary">
                          <Bot className="h-3 w-3" /> Pratinjau balasan
                        </div>
                        {testResult.data.replyText}
                      </div>
                    )}
                    {testResult.data.candidates.length > 0 && (
                      <div>
                        <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Kandidat</div>
                        <ul className="space-y-1 text-xs">
                          {testResult.data.candidates.map((c) => (
                            <li key={c.id} className="flex justify-between rounded bg-card px-2 py-1">
                              <span>{c.title}</span>
                              <span className="font-mono text-muted-foreground">skor {c.score}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Riwayat keputusan bot</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Waktu</TableHead>
                      <TableHead>Kontak</TableHead>
                      <TableHead className="w-[30%]">Pesan masuk</TableHead>
                      <TableHead>Keputusan</TableHead>
                      <TableHead>Kecocokan</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(logs.data ?? []).length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="py-8 text-center text-sm text-muted-foreground">
                          Belum ada aktivitas bot.
                        </TableCell>
                      </TableRow>
                    )}
                    {(logs.data ?? []).map((l) => (
                      <TableRow key={l.id}>
                        <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                          {new Date(l.createdAt).toLocaleString("id-ID", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                        </TableCell>
                        <TableCell className="text-sm">{l.contactName}</TableCell>
                        <TableCell className="max-w-0 truncate text-sm">{l.inputText}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={DECISION_CLS[l.decision] ?? ""}>
                            {DECISION_LABELS[l.decision] ?? l.decision}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {l.matchedTitle ? `${l.matchedTitle} (${l.score})` : `— (${l.score})`}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialog entri KB */}
      <Dialog open={kbForm != null} onOpenChange={(o) => { if (!o) setKbForm(null); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{kbForm?.id ? "Edit entri" : "Tambah entri basis pengetahuan"}</DialogTitle>
            <DialogDescription>Satu entri = satu topik jawaban. Tulis kata kunci satu per baris.</DialogDescription>
          </DialogHeader>
          {kbForm && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label>Judul topik</Label>
                <Input value={kbForm.title} onChange={(e) => setKbForm({ ...kbForm, title: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Kata kunci (satu per baris)</Label>
                <Textarea rows={4} value={kbForm.keywordsText} onChange={(e) => setKbForm({ ...kbForm, keywordsText: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Jawaban yang dikirim bot</Label>
                <Textarea rows={5} value={kbForm.answer} onChange={(e) => setKbForm({ ...kbForm, answer: e.target.value })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setKbForm(null)}>Batal</Button>
            <Button onClick={saveKb} disabled={kbCreate.isPending || kbUpdate.isPending}>Simpan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
