import { NavLink, Outlet } from "react-router";
import { MessageSquareText, ListTodo, Bot, QrCode, CircleCheckBig } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { cn } from "@/lib/utils";

const MENU = [
  { to: "/", label: "Percakapan", icon: MessageSquareText, end: true },
  { to: "/tugas", label: "Manajemen Tugas", icon: ListTodo },
  { to: "/bot", label: "Bot AI Helpdesk", icon: Bot },
  { to: "/koneksi", label: "Koneksi WhatsApp", icon: QrCode },
];

export default function AppLayout() {
  const summary = trpc.tasks.summary.useQuery(undefined, { refetchInterval: 15000 });
  const waStatus = trpc.whatsapp.status.useQuery(undefined, { refetchInterval: 15000 });
  const botSettings = trpc.bot.getSettings.useQuery(undefined, { refetchInterval: 20000 });

  const aktif = summary.data?.aktif ?? 0;
  const waConnected = waStatus.data?.status === "connected";

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      {/* Sidebar */}
      <aside className="flex w-60 shrink-0 flex-col bg-sidebar text-sidebar-foreground">
        <div className="flex items-center gap-2.5 px-5 py-5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
            <MessageSquareText className="h-5 w-5" />
          </div>
          <div>
            <div className="text-sm font-semibold tracking-wide">WA Helpdesk</div>
            <div className="text-[11px] text-sidebar-foreground/60">Dashboard Layanan</div>
          </div>
        </div>

        <nav className="mt-2 flex-1 space-y-1 px-3">
          {MENU.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors",
                  isActive
                    ? "bg-sidebar-accent font-medium text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/75 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )
              }
            >
              <item.icon className="h-4.5 w-4.5 shrink-0" />
              <span className="flex-1">{item.label}</span>
              {item.to === "/tugas" && aktif > 0 && (
                <span className="rounded-full bg-sidebar-primary px-2 py-0.5 text-[11px] font-semibold text-sidebar-primary-foreground">
                  {aktif}
                </span>
              )}
              {item.to === "/bot" && (
                <span
                  className={cn(
                    "h-2 w-2 rounded-full",
                    botSettings.data?.enabled ? "bg-emerald-400" : "bg-sidebar-foreground/30"
                  )}
                  title={botSettings.data?.enabled ? "Bot aktif" : "Bot nonaktif"}
                />
              )}
            </NavLink>
          ))}
        </nav>

        <div className="mx-3 mb-4 rounded-lg border border-sidebar-border bg-sidebar-accent/40 p-3">
          <div className="flex items-center gap-2 text-xs">
            {waConnected ? (
              <CircleCheckBig className="h-4 w-4 text-emerald-400" />
            ) : (
              <span className="h-2 w-2 rounded-full bg-amber-400" />
            )}
            <span className="font-medium">
              {waConnected ? "WhatsApp terhubung" : "WhatsApp belum terhubung"}
            </span>
          </div>
          {waConnected && waStatus.data?.phoneNumber && (
            <div className="mt-1 pl-6 text-[11px] text-sidebar-foreground/60">
              +{waStatus.data.phoneNumber} · {waStatus.data.pushName}
            </div>
          )}
        </div>
      </aside>

      {/* Konten */}
      <main className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <Outlet />
      </main>
    </div>
  );
}
