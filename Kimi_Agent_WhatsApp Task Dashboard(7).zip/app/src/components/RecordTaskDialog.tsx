import { useEffect, useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ClipboardCheck, Sparkles } from "lucide-react";
import { BEBAN_OPTIONS, BEBAN_LABELS, WAKTU_OPTIONS } from "@contracts/constants";
import { toast } from "sonner";

interface Props {
  conversationId: number;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved?: () => void;
}

export default function RecordTaskDialog({ conversationId, open, onOpenChange, onSaved }: Props) {
  const utils = trpc.useUtils();
  const draft = trpc.tasks.draftFromConversation.useQuery(
    { conversationId },
    { enabled: open, refetchOnWindowFocus: false }
  );

  const [form, setForm] = useState({
    pemohon: "", waNumber: "", tanggalPemohon: "", tanggalHarusSelesai: "",
    tugas: "", keterangan: "", masalah: "", caraPenyelesaian: "",
    tanggalJatuhTempo: "", tujuanTugas: "", beban: "ringan", waktuPenyelesaian: "1 hari",
  });
  const [markResolved, setMarkResolved] = useState(true);
  const [dasar, setDasar] = useState<{ field: string; value: string; reason: string }[]>([]);

  useEffect(() => {
    if (draft.data && open) {
      const d = draft.data;
      setForm({
        pemohon: d.pemohon, waNumber: d.waNumber, tanggalPemohon: d.tanggalPemohon,
        tanggalHarusSelesai: d.tanggalHarusSelesai, tugas: d.tugas, keterangan: d.keterangan,
        masalah: d.masalah, caraPenyelesaian: d.caraPenyelesaian,
        tanggalJatuhTempo: d.tanggalJatuhTempo, tujuanTugas: d.tujuanTugas,
        beban: d.beban, waktuPenyelesaian: d.waktuPenyelesaian,
      });
      setDasar(d.dasarAnalisis);
    }
  }, [draft.data, open]);

  const create = trpc.tasks.create.useMutation({
    onSuccess: () => {
      utils.tasks.list.invalidate();
      utils.tasks.summary.invalidate();
      toast.success("Tugas berhasil direkam dari percakapan.");
      onOpenChange(false);
      onSaved?.();
    },
    onError: (e) => toast.error(e.message),
  });
  const resolve = trpc.conversations.resolve.useMutation({
    onSuccess: () => utils.conversations.list.invalidate(),
  });

  const set = (k: keyof typeof form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  const save = () => {
    if (!form.pemohon.trim() || !form.tugas.trim()) {
      toast.error("Pemohon dan Tugas wajib diisi.");
      return;
    }
    create.mutate(
      {
        pemohon: form.pemohon,
        waNumber: form.waNumber || null,
        tanggalPemohon: form.tanggalPemohon,
        tanggalHarusSelesai: form.tanggalHarusSelesai || null,
        tugas: form.tugas,
        keterangan: form.keterangan || null,
        status: "baru",
        sumber: "bot",
        conversationId,
        masalah: form.masalah || null,
        caraPenyelesaian: form.caraPenyelesaian || null,
        tanggalJatuhTempo: form.tanggalJatuhTempo || null,
        tujuanTugas: form.tujuanTugas || null,
        beban: form.beban as "ringan" | "sedang" | "sulit",
        waktuPenyelesaian: form.waktuPenyelesaian || null,
        dasarAnalisis: JSON.stringify(dasar),
      },
      { onSuccess: () => { if (markResolved) resolve.mutate({ conversationId }); } }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ClipboardCheck className="h-5 w-5 text-primary" /> Selesaikan & rekam tugas
          </DialogTitle>
          <DialogDescription>
            Kolom di bawah diisi otomatis dari isi percakapan. Koreksi bila perlu, lalu simpan sebagai tugas.
          </DialogDescription>
        </DialogHeader>

        {draft.isLoading ? (
          <div className="py-12 text-center text-sm text-muted-foreground">Menganalisis percakapan…</div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Pemohon</Label>
                <Input value={form.pemohon} onChange={(e) => set("pemohon")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>No. WhatsApp</Label>
                <Input value={form.waNumber} onChange={(e) => set("waNumber")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Tanggal Pemohon</Label>
                <Input type="date" value={form.tanggalPemohon} onChange={(e) => set("tanggalPemohon")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Tanggal Harus Selesai (tenggat kerja)</Label>
                <Input type="date" value={form.tanggalHarusSelesai} onChange={(e) => set("tanggalHarusSelesai")(e.target.value)} />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Tugas</Label>
              <Input value={form.tugas} onChange={(e) => set("tugas")(e.target.value)} />
            </div>

            <div className="rounded-lg border border-primary/25 bg-accent/50 p-3">
              <div className="mb-3 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-primary">
                <Sparkles className="h-3.5 w-3.5" /> Rekaman percakapan
              </div>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label>Masalah</Label>
                  <Textarea rows={2} value={form.masalah} onChange={(e) => set("masalah")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Cara Penyelesaian</Label>
                  <Textarea rows={2} value={form.caraPenyelesaian} onChange={(e) => set("caraPenyelesaian")(e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Tanggal Jatuh Tempo (disebut pelanggan)</Label>
                    <Input type="date" value={form.tanggalJatuhTempo} onChange={(e) => set("tanggalJatuhTempo")(e.target.value)} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Beban Tugas</Label>
                    <Select value={form.beban} onValueChange={(v) => set("beban")(v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {BEBAN_OPTIONS.map((b) => (
                          <SelectItem key={b} value={b}>{BEBAN_LABELS[b]}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Waktu Penyelesaian</Label>
                    <Select value={form.waktuPenyelesaian} onValueChange={(v) => set("waktuPenyelesaian")(v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {WAKTU_OPTIONS.map((w) => (
                          <SelectItem key={w} value={w}>{w}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Tujuan Tugas</Label>
                    <Input value={form.tujuanTugas} onChange={(e) => set("tujuanTugas")(e.target.value)} />
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Keterangan</Label>
              <Textarea rows={2} value={form.keterangan} onChange={(e) => set("keterangan")(e.target.value)} />
            </div>

            {dasar.length > 0 && (
              <div className="rounded-lg border bg-muted/50 p-3">
                <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Dasar analisis otomatis
                </div>
                <ul className="space-y-2 text-xs">
                  {dasar.map((d, i) => (
                    <li key={i} className="leading-relaxed">
                      <span className="font-medium text-foreground">{d.field}</span>
                      <span className="text-muted-foreground"> — {d.reason}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={markResolved} onCheckedChange={(v) => setMarkResolved(v === true)} />
              Tandai percakapan sebagai selesai
            </label>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={save} disabled={create.isPending || draft.isLoading}>
            {create.isPending ? "Menyimpan…" : "Simpan sebagai tugas"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
