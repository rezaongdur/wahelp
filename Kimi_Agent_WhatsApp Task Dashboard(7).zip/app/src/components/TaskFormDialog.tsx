import { useEffect, useState } from "react";
import { trpc } from "@/providers/trpc";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  BEBAN_OPTIONS, BEBAN_LABELS, WAKTU_OPTIONS, TASK_STATUSES, TASK_STATUS_LABELS,
} from "@contracts/constants";
import { toast } from "sonner";

export interface TaskForForm {
  id: number;
  pemohon: string;
  waNumber: string | null;
  tanggalPemohon: string;
  tanggalHarusSelesai: string | null;
  tugas: string;
  keterangan: string | null;
  status: "baru" | "diproses" | "selesai";
  sumber: "manual" | "bot";
  conversationId: number | null;
  masalah: string | null;
  caraPenyelesaian: string | null;
  tanggalJatuhTempo: string | null;
  tujuanTugas: string | null;
  beban: "ringan" | "sedang" | "sulit" | null;
  waktuPenyelesaian: string | null;
  dasarAnalisis: string | null;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task?: TaskForForm | null; // null/undefined = tambah baru
}

const EMPTY = {
  pemohon: "", waNumber: "", tanggalPemohon: "", tanggalHarusSelesai: "",
  tugas: "", keterangan: "", status: "baru",
  masalah: "", caraPenyelesaian: "", tanggalJatuhTempo: "",
  tujuanTugas: "", beban: "", waktuPenyelesaian: "",
};

export default function TaskFormDialog({ open, onOpenChange, task }: Props) {
  const utils = trpc.useUtils();
  const [form, setForm] = useState(EMPTY);

  useEffect(() => {
    if (!open) return;
    if (task) {
      setForm({
        pemohon: task.pemohon,
        waNumber: task.waNumber ?? "",
        tanggalPemohon: task.tanggalPemohon,
        tanggalHarusSelesai: task.tanggalHarusSelesai ?? "",
        tugas: task.tugas,
        keterangan: task.keterangan ?? "",
        status: task.status,
        masalah: task.masalah ?? "",
        caraPenyelesaian: task.caraPenyelesaian ?? "",
        tanggalJatuhTempo: task.tanggalJatuhTempo ?? "",
        tujuanTugas: task.tujuanTugas ?? "",
        beban: task.beban ?? "",
        waktuPenyelesaian: task.waktuPenyelesaian ?? "",
      });
    } else {
      const d = new Date();
      const today = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      setForm({ ...EMPTY, tanggalPemohon: today });
    }
  }, [open, task]);

  const invalidate = () => {
    utils.tasks.list.invalidate();
    utils.tasks.summary.invalidate();
  };
  const create = trpc.tasks.create.useMutation({
    onSuccess: () => { invalidate(); toast.success("Tugas ditambahkan."); onOpenChange(false); },
    onError: (e) => toast.error(e.message),
  });
  const update = trpc.tasks.update.useMutation({
    onSuccess: () => { invalidate(); toast.success("Tugas diperbarui."); onOpenChange(false); },
    onError: (e) => toast.error(e.message),
  });

  const set = (k: keyof typeof EMPTY) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  const save = () => {
    if (!form.pemohon.trim() || !form.tugas.trim() || !form.tanggalPemohon) {
      toast.error("Pemohon, Tanggal Pemohon, dan Tugas wajib diisi.");
      return;
    }
    const payload = {
      pemohon: form.pemohon,
      waNumber: form.waNumber || null,
      tanggalPemohon: form.tanggalPemohon,
      tanggalHarusSelesai: form.tanggalHarusSelesai || null,
      tugas: form.tugas,
      keterangan: form.keterangan || null,
      status: form.status as "baru" | "diproses" | "selesai",
      conversationId: task?.conversationId ?? null,
      masalah: form.masalah || null,
      caraPenyelesaian: form.caraPenyelesaian || null,
      tanggalJatuhTempo: form.tanggalJatuhTempo || null,
      tujuanTugas: form.tujuanTugas || null,
      beban: (form.beban || null) as "ringan" | "sedang" | "sulit" | null,
      waktuPenyelesaian: form.waktuPenyelesaian || null,
    };
    if (task) update.mutate({ id: task.id, ...payload });
    else create.mutate(payload);
  };

  const pending = create.isPending || update.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{task ? "Edit tugas" : "Tambah tugas baru"}</DialogTitle>
          <DialogDescription>
            {task
              ? "Perbarui detail tugas. Kolom rekaman percakapan dapat dikoreksi manual."
              : "Isi tugas berdasarkan permintaan dari percakapan WhatsApp."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Pemohon *</Label>
              <Input value={form.pemohon} onChange={(e) => set("pemohon")(e.target.value)} placeholder="Nama pemohon" />
            </div>
            <div className="space-y-1.5">
              <Label>No. WhatsApp</Label>
              <Input value={form.waNumber} onChange={(e) => set("waNumber")(e.target.value)} placeholder="628xxxxxxxxxx" />
            </div>
            <div className="space-y-1.5">
              <Label>Tanggal Pemohon *</Label>
              <Input type="date" value={form.tanggalPemohon} onChange={(e) => set("tanggalPemohon")(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Tanggal Harus Selesai (tenggat kerja)</Label>
              <Input type="date" value={form.tanggalHarusSelesai} onChange={(e) => set("tanggalHarusSelesai")(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => set("status")(v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TASK_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>{TASK_STATUS_LABELS[s]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Tugas *</Label>
            <Input value={form.tugas} onChange={(e) => set("tugas")(e.target.value)} placeholder="Uraian singkat tugas" />
          </div>
          <div className="space-y-1.5">
            <Label>Keterangan</Label>
            <Textarea rows={2} value={form.keterangan} onChange={(e) => set("keterangan")(e.target.value)} />
          </div>

          <div className="rounded-lg border p-3">
            <div className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Rekaman percakapan (opsional)
            </div>
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label>Masalah</Label>
                <Textarea rows={2} value={form.masalah} onChange={(e) => set("masalah")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Cara Penyelesaian</Label>
                <Textarea rows={2} value={form.caraPenyelesaian} onChange={(e) => set("caraPenyelesaian")(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Tanggal Jatuh Tempo (disebut pelanggan)</Label>
                  <Input type="date" value={form.tanggalJatuhTempo} onChange={(e) => set("tanggalJatuhTempo")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Tujuan Tugas</Label>
                  <Input value={form.tujuanTugas} onChange={(e) => set("tujuanTugas")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Beban Tugas</Label>
                  <Select value={form.beban} onValueChange={(v) => set("beban")(v)}>
                    <SelectTrigger><SelectValue placeholder="Pilih…" /></SelectTrigger>
                    <SelectContent>
                      {BEBAN_OPTIONS.map((b) => (
                        <SelectItem key={b} value={b}>{BEBAN_LABELS[b]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Waktu Penyelesaian</Label>
                  <Select value={form.waktuPenyelesaian} onValueChange={(v) => set("waktuPenyelesaian")(v)}>
                    <SelectTrigger><SelectValue placeholder="Pilih…" /></SelectTrigger>
                    <SelectContent>
                      {WAKTU_OPTIONS.map((w) => (
                        <SelectItem key={w} value={w}>{w}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={save} disabled={pending}>{pending ? "Menyimpan…" : "Simpan"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
