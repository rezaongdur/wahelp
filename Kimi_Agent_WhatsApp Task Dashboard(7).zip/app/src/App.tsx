import { Routes, Route } from "react-router";
import { Toaster } from "@/components/ui/sonner";
import AppLayout from "@/components/AppLayout";
import ConversationsPage from "@/pages/ConversationsPage";
import TasksPage from "@/pages/TasksPage";
import BotPage from "@/pages/BotPage";
import SettingsPage from "@/pages/SettingsPage";

export default function App() {
  return (
    <>
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/" element={<ConversationsPage />} />
          <Route path="/tugas" element={<TasksPage />} />
          <Route path="/bot" element={<BotPage />} />
          <Route path="/koneksi" element={<SettingsPage />} />
          <Route path="*" element={<ConversationsPage />} />
        </Route>
      </Routes>
      <Toaster richColors position="top-right" />
    </>
  );
}
