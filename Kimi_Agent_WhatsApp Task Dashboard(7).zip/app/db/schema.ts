import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  boolean,
  date,
} from "drizzle-orm/mysql-core";

// Sesi koneksi WhatsApp (gateway QR). Selalu 1 baris (id = 1).
export const waSessions = mysqlTable("wa_sessions", {
  id: serial("id").primaryKey(),
  status: mysqlEnum("status", ["disconnected", "waiting_scan", "connected"])
    .notNull()
    .default("disconnected"),
  phoneNumber: varchar("phone_number", { length: 32 }),
  pushName: varchar("push_name", { length: 128 }),
  qrToken: varchar("qr_token", { length: 128 }),
  qrCreatedAt: timestamp("qr_created_at"),
  connectedAt: timestamp("connected_at"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const contacts = mysqlTable("contacts", {
  id: serial("id").primaryKey(),
  waNumber: varchar("wa_number", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const conversations = mysqlTable("conversations", {
  id: serial("id").primaryKey(),
  contactId: bigint("contact_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => contacts.id),
  lastMessageAt: timestamp("last_message_at").notNull().defaultNow(),
  lastMessagePreview: varchar("last_message_preview", { length: 255 }),
  unreadCount: int("unread_count").notNull().default(0),
  // active = bot boleh membalas; handoff = admin mengambil alih, bot diam
  botState: mysqlEnum("bot_state", ["active", "handoff"])
    .notNull()
    .default("active"),
  status: mysqlEnum("status", ["open", "resolved"]).notNull().default("open"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const messages = mysqlTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: bigint("conversation_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => conversations.id),
  direction: mysqlEnum("direction", ["in", "out"]).notNull(),
  senderType: mysqlEnum("sender_type", ["contact", "admin", "bot"]).notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const tasks = mysqlTable("tasks", {
  id: serial("id").primaryKey(),
  pemohon: varchar("pemohon", { length: 128 }).notNull(),
  waNumber: varchar("wa_number", { length: 32 }),
  tanggalPemohon: date("tanggal_pemohon", { mode: "string" }).notNull(),
  // Tenggat kerja internal (kapan petugas harus menyelesaikan)
  tanggalHarusSelesai: date("tanggal_harus_selesai", { mode: "string" }),
  tugas: text("tugas").notNull(),
  keterangan: text("keterangan"),
  status: mysqlEnum("status", ["baru", "diproses", "selesai"])
    .notNull()
    .default("baru"),
  sumber: mysqlEnum("sumber", ["manual", "bot"]).notNull().default("manual"),
  conversationId: bigint("conversation_id", { mode: "number", unsigned: true })
    .references(() => conversations.id),
  // --- Blok hasil rekaman percakapan ---
  masalah: text("masalah"),
  caraPenyelesaian: text("cara_penyelesaian"),
  // Tanggal yang disebut pelanggan dalam percakapan
  tanggalJatuhTempo: date("tanggal_jatuh_tempo", { mode: "string" }),
  tujuanTugas: text("tujuan_tugas"),
  beban: mysqlEnum("beban", ["ringan", "sedang", "sulit"]),
  waktuPenyelesaian: varchar("waktu_penyelesaian", { length: 16 }),
  // JSON string: [{field, value, reason}]
  dasarAnalisis: text("dasar_analisis"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const kbEntries = mysqlTable("kb_entries", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  // JSON string array of keyword phrases
  keywords: text("keywords").notNull(),
  answer: text("answer").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  sortOrder: int("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Pengaturan bot. Selalu 1 baris (id = 1).
export const botSettings = mysqlTable("bot_settings", {
  id: serial("id").primaryKey(),
  enabled: boolean("enabled").notNull().default(false),
  greetingMessage: text("greeting_message"),
  fallbackMessage: text("fallback_message"),
  // comma / newline separated keyword phrases
  handoffKeywords: text("handoff_keywords"),
  hoursStart: varchar("hours_start", { length: 5 }).notNull().default("08:00"),
  hoursEnd: varchar("hours_end", { length: 5 }).notNull().default("16:00"),
  // JSON string array of ISO weekday numbers, 1=Senin .. 7=Minggu
  // (default diisi aplikasi; TiDB tidak menerima default ekspresi pada text)
  workDays: text("work_days").notNull(),
  antiSpamSeconds: int("anti_spam_seconds").notNull().default(20),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const botLogs = mysqlTable("bot_logs", {
  id: serial("id").primaryKey(),
  conversationId: bigint("conversation_id", { mode: "number", unsigned: true })
    .references(() => conversations.id),
  inputText: text("input_text").notNull(),
  decision: varchar("decision", { length: 24 }).notNull(),
  matchedKbId: bigint("matched_kb_id", { mode: "number", unsigned: true }),
  matchedTitle: varchar("matched_title", { length: 255 }),
  score: int("score").notNull().default(0),
  // JSON string: [{id, title, score}]
  candidates: text("candidates"),
  replyText: text("reply_text"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
