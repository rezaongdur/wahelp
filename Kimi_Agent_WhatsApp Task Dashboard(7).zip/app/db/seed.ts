// Seed: basis pengetahuan bawaan, pengaturan bot default, dan data demo.
// Jalankan dengan: npx tsx db/seed.ts
import { getDb } from "../api/queries/connection";
import {
  botSettings,
  kbEntries,
  contacts,
  conversations,
  messages,
  tasks,
} from "./schema";
import { DEFAULT_SETTINGS } from "../api/services/inbound";

const KB: { title: string; keywords: string[]; answer: string; sortOrder: number }[] = [
  {
    title: "Jam layanan",
    keywords: ["jam layanan", "jam kerja", "jam buka", "buka jam", "kapan buka", "jam operasional"],
    answer:
      "Layanan kami buka Senin–Jumat pukul 08.00–16.00 WIB (istirahat 12.00–13.00). Di luar jam tersebut pesan Anda tetap kami terima dan akan dijawab pada hari kerja berikutnya.",
    sortOrder: 1,
  },
  {
    title: "Cara pembayaran",
    keywords: ["cara bayar", "bayar pajak", "pembayaran", "kode billing", "billing", "cara membayar", "bayar"],
    answer:
      "Pembayaran dilakukan dengan membuat kode billing terlebih dahulu di aplikasi, lalu bayar melalui bank teller, ATM, mobile banking, atau kanal pembayaran resmi lainnya menggunakan kode billing tersebut. Simpan bukti pembayaran Anda.",
    sortOrder: 2,
  },
  {
    title: "Minta salinan SKPD",
    keywords: ["skpd", "salinan skpd", "surat ketetapan", "cetak ulang skpd", "skpd hilang"],
    answer:
      "Untuk salinan SKPD, mohon kirimkan: (1) nama wajib pajak, (2) NPWPD, dan (3) masa pajak yang dimaksud. Petugas kami akan menerbitkan ulang salinan dan mengirimkannya melalui percakapan ini atau dapat diambil di kantor layanan.",
    sortOrder: 3,
  },
  {
    title: "Kendala input laporan",
    keywords: ["tidak bisa input", "gagal input", "kendala input", "input laporan", "laporan gagal", "error saat input", "tidak bisa lapor"],
    answer:
      "Untuk kendala input laporan: pastikan koneksi stabil, gunakan browser Chrome versi terbaru, bersihkan cache, dan coba kembali. Bila masih gagal, kirimkan tangkapan layar pesan error beserta NPWPD Anda agar petugas dapat menelusuri.",
    sortOrder: 4,
  },
  {
    title: "Lupa password",
    keywords: ["lupa password", "lupa kata sandi", "reset password", "tidak bisa login", "kata sandi", "reset sandi"],
    answer:
      "Untuk reset password: buka halaman login aplikasi, pilih 'Lupa Password', lalu masukkan email/NPWPD terdaftar. Tautan reset akan dikirim ke email Anda. Bila email sudah tidak aktif, petugas kami dapat membantu reset manual setelah verifikasi data.",
    sortOrder: 5,
  },
  {
    title: "Pendaftaran NPWPD",
    keywords: ["npwpd", "pendaftaran", "daftar baru", "registrasi", "cara daftar"],
    answer:
      "Pendaftaran NPWPD dapat dilakukan daring melalui menu Pendaftaran di aplikasi, atau datang langsung ke kantor layanan dengan membawa KTP, NPWP (bila ada), dan dokumen usaha. Proses verifikasi maksimal 3 hari kerja.",
    sortOrder: 6,
  },
  {
    title: "Keberatan tagihan",
    keywords: ["keberatan", "banding", "tagihan salah", "tidak sesuai", "sengketa", "ajukan keberatan"],
    answer:
      "Keberatan atas tagihan diajukan secara tertulis paling lambat 3 bulan sejak tanggal surat/tagihan diterbitkan, disertai alasan dan dokumen pendukung. Kirimkan nomor tagihan Anda di sini agar petugas dapat memeriksa terlebih dahulu sebelum Anda mengajukan resmi.",
    sortOrder: 7,
  },
  {
    title: "Jatuh tempo & sanksi",
    keywords: ["jatuh tempo", "denda", "sanksi", "keterlambatan", "telat bayar", "tenggat"],
    answer:
      "Jatuh tempo pembayaran tertera pada SKPD/tagihan Anda (umumnya 30 hari sejak terbit). Keterlambatan dikenakan sanksi administrasi sesuai ketentuan yang berlaku. Sebutkan nomor tagihan Anda bila ingin kami cek tanggal jatuh tempo pastinya.",
    sortOrder: 8,
  },
  {
    title: "Minta petugas",
    keywords: ["petugas", "bicara dengan petugas", "admin", "customer service", "operator", "manusia"],
    answer:
      "Baik, pesan Anda kami teruskan ke petugas. Mohon ditunggu, petugas akan membalas pada jam layanan (Senin–Jumat 08.00–16.00 WIB).",
    sortOrder: 9,
  },
  {
    title: "Penutup",
    keywords: ["terima kasih", "makasih", "thanks", "oke terima kasih", "baik terima kasih"],
    answer:
      "Sama-sama, senang bisa membantu! 🙏 Bila ada pertanyaan lain, silakan sampaikan kapan saja. Percakapan ini akan kami arsipkan sebagai bahan tindak lanjut.",
    sortOrder: 10,
  },
];

async function main() {
  const db = getDb();
  console.log("Seeding...");

  // Pengaturan bot default (NONAKTIF)
  const existingSettings = await db.select().from(botSettings).limit(1);
  if (!existingSettings.length) {
    await db.insert(botSettings).values({
      enabled: false,
      greetingMessage: DEFAULT_SETTINGS.greetingMessage,
      fallbackMessage: DEFAULT_SETTINGS.fallbackMessage,
      handoffKeywords: DEFAULT_SETTINGS.handoffKeywords.join("\n"),
      hoursStart: "08:00",
      hoursEnd: "16:00",
      workDays: JSON.stringify([1, 2, 3, 4, 5]),
      antiSpamSeconds: 20,
    });
    console.log("✓ bot_settings");
  }

  // Basis pengetahuan
  const existingKb = await db.select().from(kbEntries).limit(1);
  if (!existingKb.length) {
    for (const k of KB) {
      await db.insert(kbEntries).values({
        title: k.title,
        keywords: JSON.stringify(k.keywords),
        answer: k.answer,
        enabled: true,
        sortOrder: k.sortOrder,
      });
    }
    console.log(`✓ ${KB.length} entri basis pengetahuan`);
  }

  // Data demo percakapan
  const existingContacts = await db.select().from(contacts).limit(1);
  if (!existingContacts.length) {
    const now = Date.now();
    const H = 3600_000;
    const D = 24 * H;

    // Kontak 1: Budi — kendala input laporan
    const c1 = await db.insert(contacts).values({ waNumber: "6281234000001", name: "Budi Santoso" });
    const cv1 = await db.insert(conversations).values({
      contactId: Number(c1[0].insertId),
      lastMessageAt: new Date(now - 2 * H),
      lastMessagePreview: "Baik Pak, saya coba lagi sesuai saran. Terima kasih.",
      unreadCount: 0,
      botState: "active",
      status: "open",
    });
    const cv1Id = Number(cv1[0].insertId);
    const m = (cid: number, direction: "in" | "out", senderType: "contact" | "admin" | "bot", body: string, agoMs: number) =>
      db.insert(messages).values({ conversationId: cid, direction, senderType, body, createdAt: new Date(now - agoMs) });
    await m(cv1Id, "in", "contact", "Selamat pagi, saya Budi dari Restoran Sederhana", 26 * H);
    await m(cv1Id, "in", "contact", "Saya tidak bisa input laporan pajak bulan ini, muncul error terus. Laporan harus masuk sebelum tanggal 28.", 25 * H);
    await m(cv1Id, "out", "bot", "Untuk kendala input laporan: pastikan koneksi stabil, gunakan browser Chrome versi terbaru, bersihkan cache, dan coba kembali. Bila masih gagal, kirimkan tangkapan layar pesan error beserta NPWPD Anda agar petugas dapat menelusuri.", 25 * H - 60_000);
    await m(cv1Id, "in", "contact", "Baik Pak, saya coba lagi sesuai saran. Terima kasih.", 2 * H);

    // Kontak 2: Siti — minta salinan SKPD (unread)
    const c2 = await db.insert(contacts).values({ waNumber: "6281234000002", name: "Siti Rahayu" });
    const cv2 = await db.insert(conversations).values({
      contactId: Number(c2[0].insertId),
      lastMessageAt: new Date(now - 30 * 60_000),
      lastMessagePreview: "Mohon dibantu ya, butuh sebelum 10 oktober 2026 untuk keperluan bank.",
      unreadCount: 2,
      botState: "active",
      status: "open",
    });
    const cv2Id = Number(cv2[0].insertId);
    await m(cv2Id, "in", "contact", "Halo, saya Siti Rahayu, NPWPD 12.34.567", 5 * H);
    await m(cv2Id, "in", "contact", "Mohon dibantu ya, butuh sebelum 10 oktober 2026 untuk keperluan bank.", 30 * 60_000);
    await m(cv2Id, "in", "contact", "Saya butuh salinan SKPD masa pajak Agustus, dokumen aslinya hilang.", 4 * H);

    // Kontak 3: CV Maju Jaya — lupa password, sudah di-handoff admin
    const c3 = await db.insert(contacts).values({ waNumber: "6281234000003", name: "CV Maju Jaya" });
    const cv3 = await db.insert(conversations).values({
      contactId: Number(c3[0].insertId),
      lastMessageAt: new Date(now - D),
      lastMessagePreview: "Sudah bisa masuk, terima kasih banyak Pak.",
      unreadCount: 0,
      botState: "handoff",
      status: "open",
    });
    const cv3Id = Number(cv3[0].insertId);
    await m(cv3Id, "in", "contact", "Admin, kami lupa password akun aplikasi", D + 3 * H);
    await m(cv3Id, "out", "admin", "Baik, kami bantu reset manual. Password sementara sudah kami kirim, silakan ganti setelah login pertama.", D + 2 * H);
    await m(cv3Id, "in", "contact", "Sudah bisa masuk, terima kasih banyak Pak.", D);

    console.log("✓ 3 kontak & percakapan demo");

    // Data demo tugas
    const today = new Date();
    const fmt = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const plus = (n: number) => fmt(new Date(today.getTime() + n * D));
    await db.insert(tasks).values({
      pemohon: "CV Maju Jaya",
      waNumber: "6281234000003",
      tanggalPemohon: plus(-1),
      tanggalHarusSelesai: plus(0),
      tugas: "Reset password akun aplikasi CV Maju Jaya",
      keterangan: "Password sementara sudah dikirim, tunggu konfirmasi penggantian.",
      status: "diproses",
      sumber: "bot",
      conversationId: cv3Id,
      masalah: "Admin, kami lupa password akun aplikasi",
      caraPenyelesaian: "Reset manual oleh petugas, password sementara dikirim via chat.",
      tanggalJatuhTempo: null,
      tujuanTugas: "Pemulihan akses akun layanan",
      beban: "ringan",
      waktuPenyelesaian: "1 hari",
      dasarAnalisis: JSON.stringify([
        { field: "Beban Tugas", value: "ringan", reason: "Lupa password termasuk kendala rutin tanpa indikator berat." },
      ]),
    });
    await db.insert(tasks).values({
      pemohon: "H. Abdullah (Toko Kelontong Barokah)",
      waNumber: "6281234000099",
      tanggalPemohon: plus(-10),
      tanggalHarusSelesai: plus(-3),
      tugas: "Verifikasi ulang perhitungan tagihan masa pajak Juli",
      keterangan: "Pemohon mengajukan keberatan nilai tagihan; perlu cek ulang omzet yang dilaporkan.",
      status: "diproses",
      sumber: "manual",
      masalah: "Tagihan bulan Juli dinilai terlalu besar dibanding omzet sebenarnya.",
      caraPenyelesaian: "",
      tanggalJatuhTempo: plus(20),
      tujuanTugas: "Penanganan keberatan / sengketa tagihan",
      beban: "sulit",
      waktuPenyelesaian: "> 7 hari",
    });
    await db.insert(tasks).values({
      pemohon: "Koperasi Sejahtera",
      waNumber: "6281234000088",
      tanggalPemohon: plus(-6),
      tanggalHarusSelesai: plus(-5),
      tugas: "Pengiriman salinan SKPD masa pajak Juni",
      keterangan: "Salinan sudah diterbitkan dan diambil pemohon di kantor layanan.",
      status: "selesai",
      sumber: "manual",
      masalah: "Salinan SKPD Juni belum diterima.",
      caraPenyelesaian: "SKPD diterbitkan ulang dan diserahkan langsung.",
      beban: "ringan",
      waktuPenyelesaian: "1 hari",
      completedAt: new Date(today.getTime() - 5 * D),
    });
    console.log("✓ 3 tugas demo");
  }

  console.log("Seed selesai.");
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
